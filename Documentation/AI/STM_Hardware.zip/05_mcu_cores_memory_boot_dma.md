# STM32H755ZIT6 — Cores, memory, boot, bus matrix, DMA, interrupts

Source: DS12919 Rev 3 (STM32H755xI datasheet), sections 3.1-3.16, 3.44. Part: STM32H755ZIT6 = dual-core, **144-pin LQFP (20x20)**, **2 MB flash**, temp range suffix 6 (-40..+85 C ambient, Tj max 125 C), has crypto/hash. (Ordering code letters: Z=144 pins, I=2 MB, T=LQFP, 6=-40..85 C, option A = advanced mission profile VOS1/480 MHz, TR=tape&reel.) 96-bit unique ID. Datasheet does not list register-level info — see RM0399 for registers.

## Cores
| | Cortex-M7 (CPU1, "CM7") | Cortex-M4 (CPU2, "CM4") |
|---|---|---|
| Max clock | **480 MHz** (VOS0, LDO only) / 400 (VOS1) / 300 (VOS2) / 200 (VOS3) | **240 MHz** (VOS0) / 200 (VOS1) / 150 (VOS2) / 100 (VOS3) |
| FPU | single + **double precision** | single precision |
| Perf | 1027 DMIPS (2.14 DMIPS/MHz), DSP instr. | 300 DMIPS (1.25 DMIPS/MHz), DSP instr. |
| Pipeline/caches | 6-stage dual-issue, branch prediction, Harvard, **16 KB I-cache + 16 KB D-cache**, 64-bit AXI, 64-bit ITCM, 2x32-bit DTCM | 3-stage, branch pred., Harvard, 32-bit I/D/S buses; **ART accelerator** (64 x 256-bit cache lines + 256-bit buffer) for accesses to D1-domain flash/AXI-SRAM/QSPI/FMC |
| MPU | yes, 16 regions (each splittable into 8 subregions, 32 B - 4 GB) | yes, own MPU (16 regions) |
| NVIC | own NVIC1 | own NVIC2; each NVIC: 16 priority levels, up to 150 maskable IRQ channels + core lines |
| SysTick | 24-bit, one per core | one per core |
| Power domain | **D1** (with most high-perf peripherals) | **D2** (with most comms peripherals and timers) |
Cores are binary compatible. Both run boot code simultaneously by default; a flash user option byte can boot one core and clock-gate the other. Cores can be put in separate low-power states. Inter-core management uses two EXTI interrupt lines and shared peripherals/RAM (semaphores etc. -> RM0399).

## Memory
| Memory | Size | Domain / bus | Notes |
|---|---|---|---|
| Flash | **2 MB**, 2 independent banks (bank = 1 MB user = 8 x 128 KB sectors, + 128 KB system flash, + 2 KB option bytes) | D1, AXI | 266-bit flash word = 256 data bits (32 B, 8x32-bit) + 10 ECC bits; read-while-write across banks. Address 0x0800_0000-0x081F_FFFF. Prog. 100-290 us/flash word, sector erase 1-2 s, mass erase 5-13 s (depends on x8..x64 parallelism); endurance 10 kcycles; retention 20 yr @10 kcycles/55 C. Program voltage >= 1.62 V (x8/x16/x32) or 1.8 V (x64) |
| ITCM RAM | 64 KB | CM7 only (TCM) | 0 wait state, CM7 or MDMA access; **CM4 cannot access** |
| DTCM RAM | 128 KB (2x64 KB, 2x32-bit ports) | CM7 only | 0 wait state; stack/ISR data; usable in parallel by CM7 dual issue |
| AXI SRAM | 512 KB | D1 | 0x2400_0000-0x2407_FFFF (per bus-matrix note) |
| SRAM1 | 128 KB | D2 | |
| SRAM2 | 128 KB | D2 | |
| SRAM3 | 32 KB | D2 | |
| SRAM4 | 64 KB | D3 | accessible when D1/D2 are off; used by low-power peripherals (BDMA etc.) |
| Backup SRAM | 4 KB | VBAT domain | retained in Standby/VBAT; write-protected |
| Backup registers | 32 x 32-bit (128 B) | VBAT domain | not reset by system/power reset or Standby exit |
Total ~1 MB RAM (192 KB TCM + 864 KB user SRAM + 4 KB backup per feature list). All SRAM has hardware **ECC** (SECDED: 7 bits per 32-bit word, 8 bits per 64-bit word for AXI-SRAM and ITCM); single-error correction, double-error detection; software must handle ECC events.
**Security:** RDP (readout protection), PC-ROP, active tamper, secure access mode (ST root secure services in system memory + user-defined secure services in flash; available only to CM7 in secure access mode; secure code runs right after reset and is then inaccessible), secure firmware upgrade.
External memories: **FMC** (SRAM/PSRAM 4 banks/NOR/NAND with ECC up to 8 KB; SDRAM/LPSDR; 8/16/32-bit bus; FMC_CLK max = kernel clock/2, <=125 MHz sync), **Quad-SPI** (single/dual/quad, SDR & DDR, direct/polling/memory-mapped modes, up to 256 MB mapped incl. code execution, up to 133 MHz). On the Nucleo, QSPI signals are on Zio CN10 (D26-D31); no QSPI flash on board.

## Boot
Boot memory is chosen by the **BOOT0 pin** and the BOOT_ADDx option bytes (any address 0x0000_0000-0x3FFF_FFFF: flash or SRAMs; CM4 cannot boot from ITCM/DTCM). Bootloader lives in system memory and can reprogram flash over **FDCAN, USART, I2C, SPI, USB-DFU** (see AN2606). BOOT0 pin: input max 9 V. BOOT0 low = user flash (default on board); high = system bootloader.

## Bus matrix / DMA / interrupts
- Interconnect: 1 x 64-bit **AXI** matrix (D1) + 2 x 32-bit AHB matrices (D2, D3), bridges 5x AHB-APB, 2x AXI-AHB. D1: CM7 (AXIM, AHBP, AHBS), MDMA, DMA2D, LTDC, SDMMC1 masters; slaves AXI SRAM, flash A/B, QSPI, FMC, APB3/AHB3. D2: DMA1, DMA2, Ethernet MAC, SDMMC2, USB OTG masters; SRAM1-3, APB1/2, AHB1/2. D3: BDMA; SRAM4, backup SRAM, AHB4/APB4. D1<->D2<->D3 AHB cross-links.
- **DMA:** MDMA (D1, 16 channels, linked-list; reaches TCM via AHBS), DMA1 & DMA2 (D2, dual-port with FIFO, request router/DMAMUX), BDMA (D3, request router). DMAMUX can chain DMA requests from peripheral triggers.
- **DMA2D (Chrom-ART):** fill / copy / pixel-format conversion / blending, 4bpp-32bpp, CLUT, YCbCr for JPEG.
- **EXTI:** 89 lines (28 configurable + 61 direct) can wake cores/domains from Stop. **CRC unit** with programmable polynomial.
- Datasheet's debug section: SWD + JTAG, ETM-style trace port (TRACECLK/TRACED0-3 pins on PE2-PE6 area), SWO, 4 KB ETF trace FIFO, CoreSight; debug one or both cores.
- Datasheet Section 4 defers all peripheral base addresses to RM0399.
