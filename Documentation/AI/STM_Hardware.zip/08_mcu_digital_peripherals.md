# STM32H755ZIT6 — Digital communication peripherals and timers

Source: DS12919 Rev 3 sections 3.29-3.43 (and 3.15/3.16 external memory). Pin assignment: `07b_mcu_alt_function_matrix.md`. Which pins the Nucleo board already uses: files 02-04. Instance counts listed are for the whole device; availability on LQFP144 pins is limited by the AF matrix.

## Serial / bus peripherals
| Peripheral | Instances | Key specs |
|---|---|---|
| **USART** | USART1, 2, 3, 6 | async, sync/SPI master-slave, Smartcard (ISO7816), IrDA SIR, LIN, RS485 driver-enable, hardware flow control (RTS/CTS), Modbus, auto-baud, receiver timeout, 7/8/9-bit, **16-byte Tx/Rx FIFOs** (FIFO off by default), up to **12.5 Mbit/s**, own kernel clock, wake from Stop (start bit / any frame / specific frame / FIFO status), DMA |
| **UART** | UART4, 5, 7, 8 | same as USART minus synchronous SPI mode and Smartcard |
| **LPUART** | LPUART1 | half-duplex single-wire, CTS/RTS, wake from Stop; **only a 32.768 kHz LSE clock needed for <= 9600 baud**; Tx/Rx FIFO; DMA. Arduino D0/D1 on the Nucleo are LPUART1 (PB7/PB6) |
| **I2C** | I2C1-4 | I2C rev 5 spec; Standard 100 kbit/s, Fast 400 kbit/s, **Fast-mode+ 1 Mbit/s (20 mA drive pins, FT_f)**; 7/10-bit addressing; controller/target, multi-controller; SMBus 2.0 (PEC, ARP, alert) and PMBus 1.1; programmable analog/digital filters; independent clock, wake from Stop on address match; 1-byte buffer + DMA |
| **SPI/I2S** | SPI1-6 (SPI1/2/3 muxed with I2S1/2/3) | up to **150 Mbit/s** master/slave, half/full duplex/simplex, 3-bit prescaler (8 master rates), 4-16 bit frames, NSS pulse mode, TI mode, HW CRC, 8x8-bit Tx/Rx FIFO (16x8-bit for I2S); I2S: master/slave, simplex/full duplex, 16/32-bit, **8-192 kHz**, MCLK = 256 x Fs. One SPI/I2S instance sits in the low-power (D3) domain. Extra SPIs: QUADSPI, and the 4 USARTs in sync mode |
| **SAI** | SAI1-4 (two sub-blocks each) | I2S, LSB/MSB-justified, PCM/DSP, TDM, AC'97, SPDIF-out; up to 192 kHz; PDM interface for up to 6 mics; master/slave; sync/async blocks |
| **SPDIFRX** | 1 (up to 4 inputs) | IEC-60958/61937, symbol rate up to 12.288 MHz, stereo 32-192 kHz, DMA |
| **SWPMI** | 1 | single-wire protocol master (SIM/UICC interface) |
| **MDIOS** | 1 | MDIO *slave* (PHY-like register file), wake from Stop |
| **SDMMC** | SDMMC1, SDMMC2 | MMC 4.51 (1/4/8-bit), SD 4.1 and SDIO 4.0 (1/4-bit), one card at a time, up to 125 MHz, internal DMA. Nucleo Zio D43-D48 = SDMMC1 (PC8-PC12, PD2) |
| **FDCAN** | FDCAN1, FDCAN2 | CAN 2.0A/B + **CAN FD**, FDCAN1 also TT-CAN (ISO 11898-4); **10 KB shared message RAM**; optional clock-calibration unit. No CAN transceiver on the Nucleo — add external. Pins: FDCAN1 PD0/PD1 (Zio D67/D66), also PA11/PA12 |
| **USB OTG** | OTG_HS1 (FS or HS with external ULPI PHY, 480 Mbit/s), OTG_FS2 | USB 2.0 + OTG 2.0, host/device/OTG, SRP/HNP, 9 bidirectional endpoints (incl. EP0), 16 host channels, 4 KB FIFO, LPM, BCD 1.2, internal FS PHY, crystal-less (HSI48), needs 48 MHz clock, external power switch required for host. Nucleo uses FS PHY on PA11/PA12 only |
| **Ethernet MAC** | 1 | IEEE 802.3-2002, **10/100 Mbit/s**, MII (17 sig.) or **RMII (9 sig.)**, external PHY required (Nucleo: LAN8742A, RMII), dedicated DMA, 2 KB Tx + 2 KB Rx FIFOs, VLAN tag, half/full duplex, multicast filtering, **IEEE 1588v2 PTP** hardware timestamp (compare linked to TIM2 input) |
| **HDMI-CEC** | 1 | CEC protocol, wake from Stop |
| **DCMI** | 1 | 8/10/12/14-bit parallel camera, up to 80 MHz pixel clock (105 MB/s @ 60 MHz), RGB565, YCbCr 4:2:2, JPEG, raw Bayer/mono, snapshot or continuous, crop |
| **LCD-TFT (LTDC)** | 1 | 24-bit RGB parallel, up to XGA 1024x768, 2 layers, CLUT 256x24, blending/alpha, color keying, AXI master |
| **JPEG codec** | 1 | HW JPEG encode/decode (ISO 10918-1), 8-bit/channel, single clock per pixel |

## Timers (all counters freeze in debug)
| Timer | Count | Resolution | Channels | Notes |
|---|---|---|---|---|
| HRTIM1 | 1 | 6 timers (1 master + 5 slave), 480 MHz digital kernel, **2.1 ns resolution**, 10 outputs | 10 PWM outputs, 5 fault inputs, 10 external event inputs | dead-time, burst, push-pull, resonant mode, LLC/buck/boost/LED topologies |
| Advanced TIM1, TIM8 | 2 | 16-bit up/down | 4 (+complementary, 6 PWM outputs), dead time, break | three-phase motor PWM; DMA |
| TIM2, TIM5 | 2 | **32-bit** up/down | 4 | encoder/hall interface, DMA |
| TIM3, TIM4 | 2 | 16-bit up/down | 4 | encoder/hall, DMA |
| TIM12 | 1 | 16-bit up | 2 | |
| TIM13, TIM14 | 2 | 16-bit up | 1 | |
| TIM15 | 1 | 16-bit up | 2 (+1 complementary) | |
| TIM16, TIM17 | 2 | 16-bit up | 1 (+1 compl.) | |
| Basic TIM6, TIM7 | 2 | 16-bit up | 0 | DAC trigger / timebase, DMA |
| LPTIM1-5 | 5 | 16-bit up | pulse/PWM output | run in Stop (LSE/LSI/ext clock), wake-up, encoder mode |
| Watchdogs | 4 | IWDG1/2 (12-bit, 8-bit prescaler, 32 kHz LSI, runs in Stop/Standby, HW/SW enabled via option bytes), WWDG1/2 (7-bit, main clock, early-wake IRQ) | | one pair per domain |
| SysTick | 2 | 24-bit | | one per core |
All timer prescalers 16-bit (1-65536) except LPTIM (1/2/4/.../128). Max timer clock 240 MHz (480 MHz option; 150/300 MHz on extended-temperature suffix-3 parts). TIM1/8/2/3/4/5/15 etc. also usable as ADC triggers (TIM1,2,3,4,6,8,15, HRTIM1, LPTIM1).

## RTC
Calendar with sub-seconds, 2 alarms, wakeup timer (17-bit), digital calibration (0.95 ppm), 3 tamper pins with filter, timestamp, 1-32767 pulse smooth correction; clock from LSE, LSI (not functional in VBAT then), or HSE/32. Runs in VBAT mode with LSE. 128 B backup registers, 4 KB backup SRAM.
