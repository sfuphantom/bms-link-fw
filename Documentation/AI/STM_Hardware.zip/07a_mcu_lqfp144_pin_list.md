# STM32H755ZIT6 (LQFP144) - Pin list: package pin -> name, I/O type, analog/special functions

Source: STM32H755xI datasheet DS12919 Rev 3, Table 8 (LQFP144 column only). Digital alternate functions (AFx numbers) are in `07b_mcu_alt_function_matrix.md`.

I/O structure codes: FT = 5V-tolerant; FT_a = +analog; FT_h = high-speed low-voltage; FT_u = USB option (VDD33USB); FT_f = FM+ capable (20mA I2C); TT_a = 3.3V-only (NOT 5V tolerant) with analog; B = BOOT0; RST = reset. All GPIO are floating inputs after reset except debug pins; (datasheet 3.8) GPIOs are Analog mode after reset per RM.

| LQFP144 pin | Name | I/O struct | Additional/analog functions | Note |
|---|---|---|---|---|
| 1 | PE2 | FT_ h |  |  |
| 2 | PE3 | FT_ h |  |  |
| 3 | PE4 | FT_ h |  |  |
| 4 | PE5 | FT_ h |  |  |
| 5 | PE6 | FT_ h |  |  |
| 6 | VSS |  |  |  |
| 7 | VDD |  |  |  |
| 8 | VBAT |  |  |  |
| 9 | PC13 | FT | RTC_OUT/RTC_T AMP1/RTC_TS/W KUP4 |  |
| 10 | PC14- OSC32_IN(O SC32_IN)(1) | FT | OSC32_IN |  |
| 11 | PC15- OSC32_OUT (OSC32_OU T)(1) | FT | OSC32_OUT |  |
| 12 | VSS |  |  |  |
| 13 | VDD |  |  |  |
| 14 | VSSSMPS |  |  |  |
| 15 | VLXSMPS |  |  |  |
| 16 | VDDSMPS |  |  |  |
| 17 | VFBSMPS |  |  |  |
| 18 | VSS |  |  |  |
| 19 | VDD |  |  |  |
| 20 | PF6 | FT_ ha | ADC3_INN4, ADC3_INP8 |  |
| 21 | PF7 | FT_ ha | ADC3_INP3 |  |
| 22 | PF8 | FT_ ha | ADC3_INN3, ADC3_INP7 |  |
| 23 | PF9 | FT_ ha | ADC3_INP2 |  |
| 24 | PF10 | FT_ ha | ADC3_INN2, ADC3_INP6 |  |
| 25 | PH0- OSC_IN(PH 0) | FT | OSC_IN |  |
| 26 | PH1- OSC_OUT(P H1) | FT | OSC_OUT |  |
| 27 | NRST | RST |  |  |
| 28 | PC0 | FT_ a | ADC123_INP10 |  |
| 29 | PC1 | FT_ ha | ADC123_INN10, ADC123_INP11, RTC_TAMP3/WK UP6 |  |
| 32 | VDD |  |  |  |
| 33 | VSS |  |  |  |
| 34 | VSSA |  |  |  |
| 35 | VREF+ |  |  |  |
| 36 | VDDA |  |  |  |
| 37 | PA0 | FT_ a | ADC1_INP16, WKUP1 |  |
| 38 | PA1 | FT_ ha | ADC1_INN16, ADC1_INP17 |  |
| 39 | PA2 | FT_ a | ADC12_INP14, WKUP2 |  |
| 40 | PA3 | FT_ ha | ADC12_INP15 |  |
| 41 | VSS |  |  |  |
| 42 | VDD |  |  |  |
| 43 | PA4 | TT_ a | ADC12_INP18, DAC1_OUT1 |  |
| 44 | PA5 | TT_ ha | ADC12_INN18, ADC12_INP19, DAC1_OUT2 |  |
| 45 | PA6 | FT_ a | ADC12_INP3 |  |
| 46 | PA7 | TT_ a | ADC12_INN3, ADC12_INP7, OPAMP1_VINM |  |
| 47 | PC4 | TT_ a | ADC12_INP4, OPAMP1_VOUT, COMP1_INM |  |
| 48 | PC5 | TT_ a | ADC12_INN4, ADC12_INP8, OPAMP1_VINM |  |
| 49 | PB0 | FT_ a | ADC12_INN5, ADC12_INP9, OPAMP1_VINP, COMP1_INP |  |
| 50 | PB1 | TT_ a | ADC12_INP5, COMP1_INM |  |
| 51 | PB2 | FT_ ha | COMP1_INP |  |
| 52 | PF11 | FT_ a | ADC1_INP2 |  |
| 53 | PF14 | FT_f ha | ADC2_INN2, ADC2_INP6 |  |
| 54 | PF15 | FT_f h |  |  |
| 55 | VSS |  |  |  |
| 56 | VDD |  |  |  |
| 57 | PE7 | TT_ ha | OPAMP2_VOUT, COMP2_INM |  |
| 58 | PE8 | TT_ ha | OPAMP2_VINM |  |
| 59 | PE9 | TT_ ha | OPAMP2_VINP, COMP2_INP |  |
| 60 | PE10 | FT_ ha | COMP2_INM |  |
| 61 | PE11 | FT_ ha | COMP2_INP |  |
| 62 | PE12 | FT_ h |  |  |
| 63 | PE13 | FT_ h |  |  |
| 64 | PE14 | FT_ h |  |  |
| 65 | PE15 | FT_ h |  |  |
| 66 | PB10 | FT_f |  |  |
| 67 | PB11 | FT_f |  |  |
| 68 | VCAP |  |  |  |
| 69 | VSS |  |  |  |
| 70 | VDDLDO(4) |  |  |  |
| 71 | VDD |  |  |  |
| 72 | PB12(5) | FT_ u |  |  |
| 73 | PB13(5) | FT_ u | OTG_HS_VBUS |  |
| 74 | PB14 | FT_ u |  |  |
| 75 | PB15 | FT_ u |  |  |
| 76 | PD8 | FT_ h |  |  |
| 77 | PD9 | FT_ h |  |  |
| 78 | PD10 | FT_ h |  |  |
| 79 | VDD |  |  |  |
| 80 | VSS |  |  |  |
| 81 | PD11 | FT_ h |  |  |
| 82 | PD12 | FT_f h |  |  |
| 83 | PD13 | FT_f h |  |  |
| 84 | PD14 | FT_ h |  |  |
| 85 | PD15 | FT_ h |  |  |
| 86 | PG6 | FT_ h |  |  |
| 87 | PG7 | FT_ h |  |  |
| 88 | PG8 | FT_ h |  |  |
| 89 | VSS |  |  |  |
| 90 | VDD50USB (6) |  |  |  |
| 91 | VDD33USB |  |  |  |
| 92 | VDD |  |  |  |
| 93 | PC6 | FT_ h | SWPMI_IO |  |
| 94 | PC7 | FT_ h |  |  |
| 95 | PC8 | FT_ h |  |  |
| 96 | PC9 | FT_f h |  |  |
| 97 | PA8 | FT_f ha |  |  |
| 98 | PA9 | FT_ u | OTG_FS_VBUS |  |
| 99 | PA10 | FT_ u |  |  |
| 100 | PA11 | FT_ u |  |  |
| 101 | PA12 | FT_ u |  |  |
| 102 | PA13(JTMS/ SWDIO) | FT |  |  |
| 103 | VCAP |  |  |  |
| 104 | VSS |  |  |  |
| 105 | VDDLDO(4) |  |  |  |
| 106 | VDD |  |  |  |
| 107 | PA14(JTCK/ SWCLK) | FT |  |  |
| 108 | PA15(JTDI) | FT |  |  |
| 109 | PC10 | FT_ ha |  |  |
| 110 | PC11 | FT_ h |  |  |
| 111 | PC12 | FT_ h |  |  |
| 112 | PD0 | FT_ h |  |  |
| 113 | PD1 | FT_ h |  |  |
| 114 | PD2 | FT_ h |  |  |
| 115 | PD3 | FT_ h |  |  |
| 116 | PD4 | FT_ h |  |  |
| 117 | PD5 | FT_ h |  |  |
| 118 | VSS |  |  |  |
| 119 | VDD |  |  |  |
| 120 | PD6 | FT_ h |  |  |
| 121 | PD7 | FT_ h |  |  |
| 122 | PG9 | FT_ h |  |  |
| 123 | PG10 | FT_ h |  |  |
| 124 | PG11 | FT_ h |  |  |
| 125 | PG12 | FT_ h |  |  |
| 126 | PG13 | FT_ h |  |  |
| 127 | PG14 | FT_ h |  |  |
| 128 | VSS |  |  |  |
| 129 | VDD |  |  |  |
| 130 | PB3(JTDO/T RACESWO) | FT |  |  |
| 131 | PB4(NJTRS T) | FT |  |  |
| 132 | PB5 | FT |  |  |
| 133 | PB6 | FT_f |  |  |
| 134 | PB7 | FT_f a | PVD_IN |  |
| 135 | BOOT0 | B | VPP |  |
| 136 | PB8 | FT_f h |  |  |
| 137 | PB9 | FT_f h |  |  |
| 138 | PE0 | FT_ h |  |  |
| 139 | PE1 | FT_ h |  |  |
| 140 | VCAP |  |  |  |
| 141 | VSS |  |  |  |
| 142 | PDR_ON | FT |  |  |
| 143 | VDDLDO(4) |  |  |  |
| 144 | VDD |  |  |  |

Supply/special pin notes: VDDSMPS (16) must always equal VDD. VDDLDO pins 70/105/143 are the LDO supply (datasheet: 1.62-3.6 V, VDDLDO <= VDD). VCAP pins 68/103/140 = VCORE decoupling (2.2 uF each, ESR < 100 mohm; in bypass mode use 100 nF instead). SMPS pins: 14 VSSSMPS, 15 VLXSMPS (inductor), 16 VDDSMPS (must equal VDD), 17 VFBSMPS (feedback). VDD50USB (90) is the 5 V USB-VBUS-derived input of the internal 3.3 V USB regulator that produces VDD33USB (91). PDR_ON (142): pull high for normal operation; tying it low disables internal reset supervision AND the VBAT function. BOOT0 (135): max 9 V tolerance. PA13/PA14 (102/107) = SWDIO/SWCLK; PB3 (130) = JTDO/TRACESWO (SWO); PB4 (131) = NJTRST; PA15 = JTDI.
