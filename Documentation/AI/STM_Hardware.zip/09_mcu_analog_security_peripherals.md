# STM32H755ZIT6 — Analog peripherals, crypto/security blocks

Source: DS12919 Rev 3 sections 3.17-3.28 and electrical sections (analog supply rules in file 06). Analog pin names (ADCx_INPy etc.) are in `07a_mcu_lqfp144_pin_list.md` "Additional functions". On the Nucleo, VDDA/VREF+ default to VDD (R40 fitted); Zio A0-A5 = PA3, PC0, PC3_C, PB1, PC2_C/PB9, PF11/PB8; A6-A8 = PF6, PF10, PA2.

## ADC (ADC1, ADC2, ADC3)
- Resolution selectable **16, 14, 12, 10, 8 bit**; up to 36 channels in the family (each ADC shares up to 20 external channels); up to **3.6 MSPS** (max resolution).
- Single-shot or scan mode; simultaneous and interleaved sample-and-hold between ADCs; DMA support; analog watchdog (interrupt when outside thresholds); triggers from TIM1/2/3/4/6/8/15, HRTIM1, LPTIM1.
- Internal channels: **temperature sensor on ADC3_IN18** (range -40..+140 C, needs VDDA 1.7-3.6 V; factory calibration values stored in read-only system memory), VREFINT (not detailed in datasheet text read). Need VDDA >= 1.62 V; Px_C pins (e.g. PC2_C, PC3_C on Zio A4/A2) are analog-only pads, max 1 mA I/O.
- TT_a pins (PA4, PA5, PA7) are 3.3 V-only; FT_a pins max 4 V when used as analog.
## DAC
Two 12-bit buffered channels (DAC1_OUT1 = PA4, DAC1_OUT2 = PA5), 8/12-bit monotonic, left/right align, noise and triangle wave generation, dual-channel simultaneous/independent, DMA incl. underrun detection, triggers from timer updates (TIM6/7 etc.), reference VREF+ or internal VREFBUF; 1 MHz update. Note PA5 also drives LD1/Zio D13 (SB65) and SPI1_SCK on the Nucleo.
## Comparators / op-amps / sigma-delta
- **COMP1, COMP2:** rail-to-rail, programmable reference (external I/O, DAC output, internal VREFINT or 1/4, 1/2, 3/4 of it), hysteresis, speed/power selectable, polarity, wake from Stop, timer break inputs, window mode.
- **OPAMP1, OPAMP2:** rail-to-rail, GBW up to 7.3 MHz, PGA non-inverting gain 2/4/8/16 or inverting -1/-3/-7/-15, follower mode, positive input can come from DAC, output routable to ADC, offset <= 1.5 mV, bias <= 1 nA, need VDDA >= 2.0 V.
- **DFSDM1:** 8 serial input channels (SPI / Manchester, clock up to 20 MHz, 10 MHz Manchester), 4 filters (Sinc order 1-5, oversampling 1-1024, integrator 1-256), up to **24-bit** output, PDM microphone to PCM, internal ADC/memory parallel inputs, analog watchdog, short-circuit detector, extremes detector, 16 triggers, DMA.
## Crypto / security / misc
- **CRYP:** AES 128/192/256 (ECB, CBC, CTR, GCM, CCM), DES/TDES (ECB, CBC), DMA. **HASH:** MD5, SHA-1, SHA-2, HMAC. **RNG:** true RNG, 32-bit samples.
- Security features: RDP, PC-ROP, secure access mode, active tamper, secure firmware upgrade, 96-bit unique ID, CRC unit. (Memory-security detail in file 05.)
- Temperature: also see electrical limits (junction max 125 C for suffix-6 parts such as STM32H755ZIT6).
