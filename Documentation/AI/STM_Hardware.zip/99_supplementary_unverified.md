# SUPPLEMENTARY — NOT from the supplied PDFs (unverified background knowledge)

Everything in files 01-10 comes from the three supplied documents (DS12919 Rev 3, UM2408 Rev 6, DB3171 Rev 20). **This file is separate on purpose**: it is general STM32H7 knowledge written from memory, **no web lookup was done**, and it must be verified against **RM0399** (STM32H745/755/747/757 reference manual) and the ST HAL headers before relying on it. If something here conflicts with files 01-10, trust 01-10.

- Base addresses (RM0399 memory map): ITCM 0x0000_0000 (64 KB), flash bank 1 0x0800_0000, bank 2 0x0810_0000, DTCM 0x2000_0000 (128 KB), AXI SRAM 0x2400_0000 (512 KB; datasheet confirms flash and AXI range), SRAM1/2/3 0x3000_0000 / 0x3002_0000 / 0x3004_0000, SRAM4 0x3800_0000, backup SRAM 0x3880_0000. Peripheral base addresses: see RM0399.
- Dual-core boot: option bytes (BCM7 / BCM4, a.k.a. BOOT_CM7 / BOOT_CM4 and BOOT_ADD0/1) control which core boots; CM4 normally waits in CStop until CM7 releases it; HSEM (hardware semaphores) are the standard inter-core lock; the RCC/PWR must be configured by CM7 first (CM7 owns SystemClock/supply setup). Typical Cube projects: `CM7/` and `CM4/` sub-projects with `HAL_HSEM_FastTake/Release` boot synchronisation and `HAL_PWREx_ClearPendingEvent`.
- Flash wait-state table (RM0399 "Number of wait states vs ACLK and VCORE range") needed for `FLASH_LATENCY_x`; for VOS1 at 200 MHz AXI it is typically 2 WS (programming delay 2). Verify.
- Cache/DMA: DMA cannot see CM7 D-cache; use non-cacheable MPU regions or clean/invalidate for DMA buffers; DTCM/ITCM are not reachable by DMA1/2 (MDMA only).
- Ethernet with LwIP: descriptors/buffers in SRAM1-3 (D2), non-cacheable.
- ST-LINK-V3E extras (SWV viewer, VCP bridge baud) are described in UM2448/ST-LINK-V3 documentation, not supplied.
- Software: STM32CubeH7 firmware package (HAL/LL/BSP + `Nucleo_H755ZI_Q` BSP examples), STM32CubeProgrammer, STM32CubeMX.
