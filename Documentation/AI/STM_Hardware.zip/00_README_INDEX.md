# HANDOFF INDEX — STM32H755ZIT6 on NUCLEO-H755ZI-Q (MB1363)

Scope: only the **STM32H755ZIT6** (dual Cortex-M7 480/400 MHz + Cortex-M4 240/200 MHz, 2 MB flash, ~1 MB RAM, LQFP144, internal SMPS) mounted on the **NUCLEO-H755ZI-Q** board (Digi-Key 497-NUCLEO-H755ZI-Q-ND). Files were distilled from: STM32H755xI datasheet DS12919 Rev 3 (246 pp), board user manual UM2408 Rev 6 (MB1363, 57 pp), Nucleo-144 data brief DB3171 Rev 20. Branding, mechanical, compliance, disposal and other-board content were dropped; figure/diagram info was folded into text. **No web sources were used** (see file 99 for clearly-labelled unverified background notes).

## Load only what the task needs
| File | Load when working on... |
|---|---|
| `01_board_power_and_jumpers.md` | powering the board, JP2/JP4/JP5, SMPS vs LDO, can't connect to target |
| `02_board_debug_stlink_leds_buttons.md` | SWD/ST-LINK, CN5, VCP serial console, LEDs, buttons |
| `03_board_connectors_zio_morpho_pinmap.md` | which pin is on which Zio/morpho/Arduino pin, shield compatibility |
| `04_board_peripherals_and_solder_bridges.md` | clocks (HSE/LSE), USB, Ethernet, motor control, solder bridges |
| `05_mcu_cores_memory_boot_dma.md` | cores, memories, ECC, boot, DMA, bus matrix |
| `06_mcu_power_clocks_lowpower_electrical.md` | VOS/frequency limits, supplies, abs-max ratings, low-power |
| `07a_mcu_lqfp144_pin_list.md` | package pin numbers, analog/special pin functions, 5 V tolerance |
| `07b_mcu_alt_function_matrix.md` | AF numbers for GPIO muxing (largest file) |
| `08_mcu_digital_peripherals.md` | USART/SPI/I2C/CAN/USB/ETH/SDMMC/timers specs |
| `09_mcu_analog_security_peripherals.md` | ADC/DAC/COMP/OPAMP/DFSDM/crypto |
| `10_firmware_bringup_defaults_and_pitfalls.md` | **start here for firmware**: required init, default pins, traps |
| `99_supplementary_unverified.md` | background knowledge NOT from the PDFs; verify first |

## Five facts that prevent most mistakes
1. Board default is **SMPS direct supply** -> firmware must call `HAL_PWREx_ConfigSupply(PWR_DIRECT_SMPS_SUPPLY)`; mismatch bricks debug access until BOOT0 recovery. Max CPU = **400 MHz** (VOS0/480 MHz needs LDO hardware config).
2. HSE is an **8 MHz clock from ST-LINK (bypass)**; board has a 32.768 kHz LSE crystal.
3. Console = **USART3 PD8/PD9** via ST-LINK VCP; Arduino D0/D1 are LPUART1 PB7/PB6.
4. GPIOs reset to analog mode; several MCU pins are shared with on-board functions (LEDs, Ethernet RMII, SWD, SMPS control) — see file 03/04 conflict lists.
5. Power the board **before** plugging a cable into USB CN13; use the JP2 order procedure when powering from VIN/EXT.

## Source-document inconsistencies noticed
- UM2408 7.4.1 says 500 mA USB request; 7.4.6 says 300 mA.
- UM2408 text for VIN refers to "Table 4"; correct table is Table 5. LD6 description in 7.6 mistakenly says "LD5".
- UM2408 labels Zio D68-D70 as I2C_2; datasheet shows PF14/PF15/PB5 only on **I2C4**.
- Default (bold) solder-bridge states were lost in PDF text; defaults are given only where prose states them (e.g., A4/A5 ADC-vs-I2C default is unclear).
- DB3171 lists H755ZI-Q user manual as UM2408 (MB1363); the manual also covers H745/H7A3 — H7A3 has no Ethernet.
