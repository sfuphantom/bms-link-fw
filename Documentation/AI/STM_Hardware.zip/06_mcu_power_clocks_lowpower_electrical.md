# STM32H755ZIT6 — Power, clocks, resets, low-power modes, key electrical limits

Source: DS12919 Rev 3 sections 3.5-3.7, 3.19, 6.2-6.3 and selected tables. (Board-level wiring of these rails: see `01_board_power_and_jumpers.md`.)

## Supply pins and ranges
| Supply | Range | Purpose |
|---|---|---|
| VDD | 1.62-3.6 V | I/O supply (Nucleo: 3.3 V default, 1.8 V via JP5) |
| VDDLDO | 1.62-3.6 V (<= VDD) | internal LDO regulator input (1.2 V min only during power-up with SMPS feeding LDO) |
| VDDSMPS | 1.62-3.6 V, **must equal VDD** | SMPS step-down input |
| VLXSMPS / VFBSMPS | | SMPS inductor output / feedback (VCORE, or 1.8 V / 2.5 V when SMPS feeds the LDO or external circuitry) |
| VDDA | 1.62-3.6 V (ADC/COMP >=1.62; DAC >=1.8; VREFBUF >=1.8; OPAMP >=2.0 V) | analog |
| VDD33USB | 3.0-3.6 V when USB used | USB PHY supply; VDD50USB (5 V from VBUS) feeds internal regulator to make it; regulator can be bypassed |
| VBAT | 1.2-3.6 V | RTC, backup regs, backup SRAM when VDD absent; with PDR_ON tied to VSS the VBAT function is lost |
| VCAP | VCORE: 1.0/1.1/1.2/1.35 V by VOS | 2.2 uF (+/-20 %, ESR<100 mOhm) per VCAP pin; two pins |
Power-up/down rule: while VDD < 1 V, VDDA/VDD33USB/VDD50USB must stay < VDD + 300 mV; above 1 V they are independent (VDDSMPS always = VDD). During power-down VDD may temporarily be below other rails only if energy into the MCU < 1 mJ. Supervisors: POR, PDR (PDR_ON pin can disable), PVD, BOR (3 thresholds 2.1-2.7 V via option bytes).

## VCORE source and voltage scaling (VOS) — max frequencies
| Power scale | VCORE (typ) | VCORE from LDO | VCORE from SMPS direct | Max CM7 / CM4 clock | Max Tj |
|---|---|---|---|---|---|
| VOS0 (boost) | 1.35 V | **yes, 480/240 MHz, Tj<=105 C** | **NOT available** | 480 / 240 MHz | 105 C |
| VOS1 | 1.20 V | yes | yes | 400 / 200 | 125 C |
| VOS2 | 1.10 V | yes | yes | 300 / 150 | 125 C (140 for ext. range) |
| VOS3 | 1.00 V | yes | yes | 200 / 100 | 125 C |
Also: AXI/AHB bus clock max = 240 (VOS0), 200 (VOS1), 150 (VOS2), 100 (VOS3) MHz; **APB max 120 / 100 / 75 / 50 MHz**. Timer kernel clock max 240 MHz (up to 480 MHz selectable via TIMPRE/D2PRE), HRTIM kernel up to 480 MHz. Stop-mode scales SVOS3-SVOS5 (SVOS3: wake-capable UART/SPI/I2C/LPTIM stay active; SVOS4/5 peripherals off, wake via GPIO/async IRQ).
**On the Nucleo-H755ZI-Q the default is SMPS direct => CPU max 400 MHz; 480 MHz needs hardware rework to LDO (+ matching firmware).**
SMPS modes: direct VCORE supply (follows run/stop/standby modes); feeds LDO at 1.8 V or 2.5 V; or external supply output (forced high-performance with SDEXTHP=1 in PWR_CR3). Voltage scaling set by PWR_D3CR VOS bits and SYSCFG_PWRCR ODEN (VOS0).

## Clocks (RCC, in D3)
- Internal: HSI 64 MHz (system starts on it), HSI48 (USB/RNG crystal-less), CSI 4 MHz, LSI 32 kHz. External: HSE 4-48 MHz crystal (4-50 MHz external clock), LSE 32.768 kHz. **3 PLLs** (PLL1 system, PLL2/PLL3 kernel clocks, fractional mode). USB needs a 48 MHz kernel clock (from PLL or HSI48). MCO outputs (PA8 = MCO1 AF0).
- Peripherals with dual clock domains (bus interface vs kernel) keep baud rate while system clock changes.
- Resets: POR, BOR, NRST pin, IWDG1/2 (per domain), WWDG1/2, software, low-power security reset, Standby exit.

## Low-power modes
CSleep (CPU clock off; WFI/WFE/SLEEPONEXIT), CStop (CPU subsystem clock off), DStop (domain bus matrix clock off), Stop (system clock off), DStandby (domain powered down), Standby (system off). System/domain mapping: Run = D1/D2 in DRun/DStop/DStandby, D3 DRun; Stop = D1/D2 DStop/DStandby, D3 DStop; Standby = all DStandby. A domain only sleeps when its CPU and all its allocated peripherals are idle; the other CPU can re-init clocks after Stop while the slave CPU stays held. Features list: 2.95 uA Standby (backup SRAM off, RTC/LSE on). VBAT mode: external events/RTC alarm do NOT exit it.
Wakeup times (typ/max): Sleep 9/10 CPU cycles; Stop VOS3 HSI flash-normal 4.4/5.6 us, VOS5 CSI 68/75 us; Standby 390/500 us.
Run current (typ, all periph off, LDO, CoreMark from ITCM on M7 / flash on M4, Tj 25 C): VOS0 480/240 MHz = 179 mA; VOS1 400/200 = 132 mA; VOS2 300/150 = 91 mA; VOS3 200/100 = 56 mA.

## Absolute maximum ratings (do not exceed)
- Any supply (VDD, VDDLDO, VDDSMPS, VDDA, VDD33USB, VBAT) vs VSS: -0.3 to **4.0 V**.
- Input on **FT_xxx pins** (5 V tolerant): up to min(min(VDD,VDDA,VDD33USB,VBAT)+4.0, 6 V); above ~4 V internal pull-up/down must be disabled; an FT_a pin used by analog peripheral max 4 V. **TT_xx pins** (3.3 V only, e.g. PA4, PA5, PA7): max 4.0 V. BOOT0 max 9.0 V. Other pins 4.0 V.
- Current: per I/O sink/source 20 mA (Px_C pins 1 mA); total all I/O 140 mA; total VDD in/VSS out 620 mA; injected -5/+0 mA per pin (0/0 for PA4, PA5); sum injected +/-25 mA.
- Tj max 125 C (suffix 6; 140 C for suffix 3); storage -65..150 C.
## I/O characteristics
VIL <= 0.3 VDD (or 0.4 VDD - 0.1), VIH >= 0.7 VDD (or 0.47 VDD + 0.25); hysteresis 250 mV; weak pull-up/down 30-50 kOhm (40 typ); pin capacitance ~5 pF. Output: VOL <= 0.4 V @ +8 mA (VDD 2.7-3.6 V); VOH >= VDD-0.4 V @ -8 mA; at 20 mA VOL <= 1.3 V; Fast-mode+ (FT_f) pins sink 20 mA at <= 0.4 V (VDD>=2.3 V). Leakage <= +/-250 nA. All GPIOs high-current capable with speed selection (EMI/power); all pins analog-input after reset except debug.
