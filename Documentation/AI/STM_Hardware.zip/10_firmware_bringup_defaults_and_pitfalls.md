# NUCLEO-H755ZI-Q firmware handoff — default hardware state, pin usage, pitfalls

Audience: an AI/engineer writing firmware (HAL/LL/bare-metal, STM32CubeIDE/IAR/Keil) for **STM32H755ZIT6** on **NUCLEO-H755ZI-Q (MB1363)**. Everything here is from the supplied datasheet (DS12919 Rev 3) and board manual (UM2408 Rev 6); items I could not verify are in `99_supplementary_unverified.md`. Hardware detail is in files 01-09.

## 1. Mandatory first lines (supply configuration)
Board default = **internal SMPS directly supplies VCORE (supply config 2)**. Firmware must select the same, before clock/PLL setup, in `SystemClock_Config()` (CM7 project):
```c
HAL_PWREx_ConfigSupply(PWR_DIRECT_SMPS_SUPPLY);   // default board
// HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);        // only if board reworked to LDO config 1
```
A mismatch = ST-LINK can no longer connect after reset. Recovery: power off, wire BOOT0 (CN11 pin 7) to 3V3 (CN11 pin 5), power on, STM32CubeProgrammer -> erase flash, power off, remove wire.
Voltage scaling constraint: with SMPS-direct, **VOS0 is unavailable -> choose VOS1 (max 400 MHz M7, 200 MHz M4/AXI/AHB, APB 100 MHz)**; VOS0/480 MHz needs LDO supply + rework + Tj <= 105 C. Flash wait states depend on ACLK and VCORE range — use the RM0399 table (not in supplied docs); with HAL, derive from the `FLASH_LATENCY_x` passed to `HAL_RCC_ClockConfig`.

## 2. Clock defaults
- HSE source = **8 MHz MCO from ST-LINK on PH0 (bypass mode)**, not a crystal (SB72 ON). Use `RCC_HSE_BYPASS` (digital bypass) with HSE_VALUE = 8 MHz. If the board is changed to the 25 MHz crystal X2 (SB3/SB4 ON, SB72/SB71 OFF) use `RCC_HSE_ON` and 25 MHz.
- LSE = 32.768 kHz crystal X3 (on-board). HSI 64 MHz is the reset system clock. HSI48 can serve USB (no HSE needed) and RNG.
- Bus limits at VOS1: APB <= 100 MHz, AXI/AHB <= 200 MHz. Timer kernel clock max 240 MHz (up to 480 MHz via TIMPRE/D2PRE bits).
- USB needs 48 MHz exact (PLL or HSI48 + CRS). Ethernet RMII 50 MHz ref clock is supplied by the PHY on PA1.

## 3. Pin/function defaults a firmware author must respect
| Function | Pins | Config notes |
|---|---|---|
| ST-LINK VCP (printf/console) | **USART3 TX=PD8, RX=PD9** (AF7) | default route; 115200 typical; USART3 kernel clock must be configured |
| User LEDs | LD1 PB0 (green), LD2 PE1 (yellow), LD3 PB14 (red) | push-pull, active HIGH |
| User button B1 | PC13 (blue), EXTI line 13; pull/polarity not stated in the manual — check schematic | pins default analog after reset: must enable GPIO clock and set as input |
| Reset button | NRST | |
| SWD | PA13 SWDIO, PA14 SWCLK, PB3 SWO | don't reconfigure; avoid GPIO use |
| USB FS device/host | PA11 DM, PA12 DP (AF10 OTG_FS), PA9 VBUS, PD10 power-enable (host), PG7 overcurrent | power board before plugging CN13 |
| Ethernet RMII | PA1 REF_CLK, PA2 MDIO, PC1 MDC, PA7 CRS_DV, PC4 RXD0, PC5 RXD1, PG11 TX_EN, PG13 TXD0, PB13 TXD1 (all AF11) | PHY LAN8742A, 10/100; PHY clock 50 MHz from PHY; set GPIO speed very high |
| Arduino UART D0/D1 | PB7 RX / PB6 TX = **LPUART1** (AF8) | not the VCP |
| Arduino I2C D14/D15 | PB9 SDA / PB8 SCL = I2C1 (AF4), 5 V-tolerant FT pins | external pull-ups needed (none specified on board) |
| Arduino SPI | PA5 SCK, PA6 MISO, PB5 MOSI (SPI1 AF5), PD14 CS (SB56 OFF/SB57 ON for D11 on H755) | D13 shared with LD1 only if SB65 ON |
| QSPI (Zio D26-D31) | PG6 NCS, PB2 CLK, PD11 IO0, PD12 IO1, PE2 IO2, PD13 IO3 | no flash fitted |
| FDCAN1 | PD0 RX, PD1 TX (Zio D67/D66) | needs external transceiver |
| TIM1 PWM (Zio D3-D6, D37-D42) | PE13 CH3, PE11 CH2, PA8 CH1, PE15 BKIN1, PE8 CH1N, PE10 CH2N, PE12 CH3N, PE7 ETR | |

Pin sharing traps: PB5 = D11/D22/D70; PB2 = D27/D72; PE2 = D31/D56; PE6 = D59/D38; PB3 = D23 & SWO; PA5 = D13 & LD1 (SB65); PB14 = D65 & LD3; PB13 = D18 & RMII_TXD1; PA2 = A8 & RMII_MDIO; PA8 = D6 & MCO1/USB SOF; PG8/9/10/12 = D50/D8/D49/D7 & ext-SMPS lines. After reset GPIOs are **analog mode** (except SWD/JTAG pins) — enable RCC GPIO clocks and configure mode, speed, pull, AF.

## 4. Dual-core (CM7 + CM4) facts from the datasheet
- Separate cores with separate NVICs, SysTicks, MPUs, power domains (CM7 in D1, CM4 in D2). Both boot by default; a flash option byte can boot only one core and clock-gate the other.
- **CM4 cannot access ITCM/DTCM** and cannot boot from them. CM4 reaches D1 memories (flash, AXI SRAM, QSPI, FMC) through the ART-accelerated path.
- Domains D1/D2/D3 power up independently; a CPU can use only peripherals allocated to a powered domain; each core can enter CSleep/CStop independently; Stop/Standby entered only when all domains agree.
- Peripherals in D1 (e.g., FMC/QSPI/LTDC/DMA2D/SDMMC1/JPEG/flash) are reached by CM4 through the D2-to-D1 AHB link (ART accelerator speeds CM4 instruction fetch from D1 memories).
- Debug: one core at a time or both; breakpoints, SWV, ETM trace, trigger in/out.
- Interrupts: 2 EXTI lines for inter-core signalling; semaphore/shared-RAM scheme is described in RM0399 (not supplied).

## 5. Power-measurement caveat
IDD jumper JP4 removal for current measurement; on Rev C01 boards Standby IDD is not measurable without removing parts; Rev D01 (MB1363-H755ZIQ-D01) is fixed. Set PA13/PB3/PD8 to pull-up/pull-down for ultra-low-power measurements (level shifters on VDD).

## 6. Quick-start for hardware check (from manual)
1. JP2 on 1-2 (STLK), JP4 fitted, JP5 on 1-2 (3.3 V). 2. Install ST-LINK driver if Windows < 10. 3. USB cable to **CN1**: LD5 green and LD4 on, LD3 red blinks. 4. Press B1: blinking rate of LD1-LD3 changes. 5. Get STM32CubeH7 examples from st.com.
Toolchains: STM32CubeIDE, IAR EWARM (Windows), Keil MDK-ARM (Windows). Host: Windows 10, Linux 64-bit, macOS; USB Type-A/C to Micro-B cable.
