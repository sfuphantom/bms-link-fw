# NUCLEO-H755ZI-Q — Board connectors: ST Zio (CN7/8/9/10) and ST morpho (CN11/12) pin maps

Source: UM2408 Rev 6 Tables 17 and 19 (H755 column only; H7A3 differences omitted). MCU: STM32H755ZIT6 LQFP144. All I/O are **3.3 V logic** (Arduino shields assume 5 V). Zio = Arduino Uno V3 subset (A0-A5, D0-D15) + extension (A6-A8, D16-D72).

Figure info (extension-connector diagram): CN7 and CN10 are the right-hand 2x(10/17) and 2x17 Zio headers; CN8 and CN9 are the left-hand ones. Odd pins form one row, even pins the other. Zio sockets are female on top, male underneath. CN11/CN12 morpho headers (2x35, outer edges) are **unpopulated by default** (OFF) — solder pin headers to use them; all MCU signals/power are on them. Motor-control shields need CN11 and CN12 fitted (Samtec TSW-135-07-x-D).

## Arduino compatibility settings
For Arduino Uno V3 shields: **SB39 and SB62 ON, SB40 and SB69 OFF** so A4/A5 are I2C (PB9/PB8) — otherwise A4/A5 are analog (PC2_C / PF11). (Prose in Table 16 lists the ADC choice as the ON,ON,OFF,OFF row; the manual's default is not recoverable from the text — check the board.) Remove R40 before using Arduino shield VREF+ on CN7 pin 6 (AREF).

## CN8 (left, power + SDMMC) — odd pins power, even pins D43-D50
| Pin | Signal | MCU pin / function |
|---|---|---|
| 1 | NC | |
| 3 | IOREF | 3.3 V ref |
| 5 | NRST | reset |
| 7 | 3V3 | 3.3 V in/out |
| 9 | 5V | 5 V output |
| 11, 13 | GND | |
| 15 | VIN | 7-11 V power input |
| 2 | D43 | PC8 SDMMC_D0 |
| 4 | D44 | PC9 SDMMC_D1 / SAI2_EXTCLK |
| 6 | D45 | PC10 SDMMC_D2 |
| 8 | D46 | PC11 SDMMC_D3 |
| 10 | D47 | PC12 SDMMC_CK |
| 12 | D48 | PD2 SDMMC_CMD |
| 14 | D49 | PG10 I/O (shared with SMPS_SW) |
| 16 | D50 | PG8 I/O (shared with SMPS_V1) |

## CN9 (left, analog / I2C_B / CAN / USART_B / SAI)
| Pin | Signal | MCU pin / function | Pin | Signal | MCU pin / function |
|---|---|---|---|---|---|
| 1 | A0 | PA3 ADC12_INP15 | 2 | D51 | PD7 USART_B_SCLK (USART2) |
| 3 | A1 | PC0 ADC123_INP10 | 4 | D52 | PD6 USART_B_RX |
| 5 | A2 | PC3_C ADC3_INP1 | 6 | D53 | PD5 USART_B_TX |
| 7 | A3 | PB1 ADC12_INP5 | 8 | D54 | PD4 USART_B_RTS |
| 9 | A4 | PC2_C ADC3_INP0 *or* PB9 I2C1_SDA | 10 | D55 | PD3 USART_B_CTS |
| 11 | A5 | PF11 ADC1_INP2 *or* PB8 I2C1_SCL | 12 | GND | |
| 13 | D72 | PB2 COMP1_INP (NC by default) | 14 | D56 | PE2 SAI_A_MCLK (SAI1_A) |
| 15 | D71 | PE9 COMP2_INP | 16 | D57 | PE4 SAI_A_FS |
| 17 | D70 | PB5 I2C_B_SMBA (I2C4_SMBA AF6; NC by default) | 18 | D58 | PE5 SAI_A_SCK |
| 19 | D69 | PF14 I2C_B_SCL (I2C4_SCL, AF4) | 20 | D59 | PE6 SAI_A_SD |
| 21 | D68 | PF15 I2C_B_SDA (I2C4_SDA, AF4) | 22 | D60 | PE3 SAI_B_SD (SAI1_B) |
| 23 | GND | | 24 | D61 | PF8 SAI_B_SCK |
| 25 | D67 | PD0 CAN_RX (FDCAN1) | 26 | D62 | PF7 SAI_B_MCLK |
| 27 | D66 | PD1 CAN_TX (FDCAN1) | 28 | D63 | PF9 SAI_B_FS |
| 29 | D65 | PB14 I/O (also LD3 red) | 30 | D64 | PD10 I/O (NC by default; = USB_FS_PWR_EN, JP8) |
(Note: the board manual labels the D68-D70 group "I2C_2", but the datasheet AF table shows PF14/PF15/PB5 only offer **I2C4** (SCL/SDA/SMBA) — use I2C4. Arduino D14/D15 = PB9/PB8 = I2C1.)

## CN7 (right, Arduino SPI/I2C/D8-D15 + I2S/SPI_B)
| Pin | Signal | MCU pin / function | Pin | Signal | MCU pin / function |
|---|---|---|---|---|---|
| 1 | D16 | PC6 I2S_A_MCK (I2S2) | 2 | D15 | PB8 I2C1_SCL (Arduino) |
| 3 | D17 | PB15 I2S_A_SD | 4 | D14 | PB9 I2C1_SDA (Arduino) |
| 5 | D18 | PB13 I2S_A_CK (NC by default; = RMII_TXD1, see SB8/JP6) | 6 | AREF | AVDD/VREF+ |
| 7 | D19 | PB12 I2S_A_WS | 8 | GND | |
| 9 | D20 | PA15 I2S_B_WS (I2S3) | 10 | D13 | PA5 SPI1_SCK (Arduino; also LD1 if SB65 ON) |
| 11 | D21 | PC7 I2S_B_MCK | 12 | D12 | PA6 SPI1_MISO |
| 13 | D22 | PB5 I2S_B_SD / SPI3_MOSI | 14 | D11 | PB5 SPI1_MOSI / TIM3_CH2 (SB56 OFF, SB57 ON for H755) |
| 15 | D23 | PB3 I2S_B_CK / SPI3_SCK (= SWO) | 16 | D10 | PD14 SPI1_CS / TIM4_CH3 |
| 17 | D24 | PA4 SPI3_NSS | 18 | D9 | PD15 TIM4_CH4 |
| 19 | D25 | PB4 SPI3_MISO | 20 | D8 | PG9 I/O (= SMPS_EN) |

## CN10 (right, analog ref, QSPI, timers, USART_A, TIM1)
| Pin | Signal | MCU pin / function | Pin | Signal | MCU pin / function |
|---|---|---|---|---|---|
| 1 | VDDA | analog VDD | 2 | D7 | PG12 I/O (= SMPS_PG) |
| 3 | AGND | | 4 | D6 | PA8 TIM1_CH1 (= USB_SOF / MCO1) |
| 5 | GND | | 6 | D5 | PE11 TIM1_CH2 |
| 7 | A6 | PF6 ADC3_INP8 | 8 | D4 | PE14 I/O |
| 9 | A7 | PF10 ADC3_INP6 | 10 | D3 | PE13 TIM1_CH3 |
| 11 | A8 | PA2 ADC12_INP14 (NC by default; = RMII_MDIO, JP7) | 12 | D2 | PG14 I/O |
| 13 | D26 | PG6 QSPI_CS (BK1) | 14 | D1 | PB6 LPUART1_TX (Arduino USART_A_TX) |
| 15 | D27 | PB2 QSPI_CLK | 16 | D0 | PB7 LPUART1_RX (Arduino USART_A_RX) |
| 17 | GND | | 18 | D42 | PE8 TIM1_CH1N |
| 19 | D28 | PD13 QSPI_BK1_IO3 | 20 | D41 | PE7 TIM1_ETR |
| 21 | D29 | PD12 QSPI_BK1_IO1 | 22 | GND | |
| 23 | D30 | PD11 QSPI_BK1_IO0 | 24 | D40 | PE10 TIM1_CH2N |
| 25 | D31 | PE2 QSPI_BK1_IO2 | 26 | D39 | PE12 TIM1_CH3N |
| 27 | GND | | 28 | D38 | PE6 I/O |
| 29 | D32 | PA0 TIM2_CH1 (needs SB89 ON; also B1 alt) | 30 | D37 | PE15 TIM1_BKIN1 |
| 31 | D33 | PB0 TIM3_CH3 (= LD1 green when SB54 ON) | 32 | D36 | PB10 TIM2_CH3 |
| 33 | D34 | PE0 TIM4_ETR | 34 | D35 | PB11 TIM2_CH4 |

### MCU pins that appear on TWO Zio signals (double-connected — don't drive both)
PB2 = D27 / D72; PB5 = D11 / D22 / D70; PE2 = D31 / D56; PE6 = D59 / D38; PB3 = D23 / SWO. Also board-function conflicts: PB14 = D65 / LD3 (remove R75); PA5 = D13 / LD1 (SB65); PG10/PG8/PG9/PG12 = D49/D50/D8/D7 / external-SMPS control; PD10 = D64 / USB power switch; PB13 = D18 / RMII_TXD1; PA2 = A8 / RMII_MDIO; PA8 = D6 / USB_SOF/MCO1.

## ST morpho CN11 / CN12 pin assignment (H755)
Pins are paired: odd pin / even pin per row. **CN11** (left), **CN12** (right).
| CN11 pin | odd | even | | CN12 pin | odd | even |
|---|---|---|---|---|---|---|
| 1/2 | PC10 | PC11 | | 1/2 | PC9 | PC8 |
| 3/4 | PC12 | PD2 | | 3/4 | PB8 | PC6 |
| 5/6 | 3V3_VDD | 5V_EXT | | 5/6 | PB9 | PC5 |
| 7/8 | BOOT0 | GND | | 7/8 | VREFP | 5V_USB_STLK |
| 9/10 | PF6 | NC | | 9/10 | GND | PD8 |
| 11/12 | PF7 | IOREF | | 11/12 | PA5 | PA12 or NC |
| 13/14 | PA13 (SWDIO) | NRST | | 13/14 | PA6 | PA11 or PE6 |
| 15/16 | PA14 (SWCLK) | 3V3 | | 15/16 | PA7 | PB12 |
| 17/18 | PA15 | 5V | | 17/18 | PB6 | PB11 |
| 19/20 | GND | GND | | 19/20 | PC7 | GND |
| 21/22 | PB7 | GND | | 21/22 | PA9 | PB2 |
| 23/24 | PC13 | VIN | | 23/24 | PA8 | PB1 |
| 25/26 | PC14 | NC | | 25/26 | PB10 | PB15 |
| 27/28 | PC15 | PA0 | | 27/28 | PB4 | PB14 or PE15 |
| 29/30 | PH0 | PA1 | | 29/30 | PB5 or PA4 | PB13 or PE8 |
| 31/32 | PH1 | PA4 | | 31/32 | PB3 | AGND |
| 33/34 | VBAT | PB0 | | 33/34 | PA10 | PC4 |
| 35/36 | PC2 | PC1 | | 35/36 | PA2 | NC |
| 37/38 | PC3 | PC0 | | 37/38 | PA3 | NC |
| 39/40 | PD4 | PD3 | | 39/40 | GND | PE8 |
| 41/42 | PD5 | NC | | 41/42 | PD13 | PF10 |
| 43/44 | PD6 | NC | | 43/44 | PD12 | PE7 |
| 45/46 | PD7 | PE2 | | 45/46 | PD11 | PD14 |
| 47/48 | PE3 | PE4 | | 47/48 | PE10 | PD15 |
| 49/50 | GND | PE5 | | 49/50 | PE12 | PF14 |
| 51/52 | NC | NC | | 51/52 | PE14 | PE9 |
| 53/54 | NC | PF8 | | 53/54 | PE15 | GND |
| 55/56 | PD1 | PF9 | | 55/56 | PE13 | PE11 |
| 57/58 | PD0 | NC | | 57/58 | NC | NC |
| 59/60 | NC | GND | | 59/60 | NC | PF15 |
| 61/62 | PE1 | PE6 | | 61/62 | PG14 | PF11 |
| 63/64 | PG9 | NC | | 63/64 | GND | PE0 |
| 65/66 | PG12 | PG10 | | 65/66 | PD10 | PG8 |
| 67/68 | NC | PG13 | | 67/68 | PG7 | NC |
| 69/70 | PD9 | PG11 | | 69/70 | NC | PG6 |

Notes: BOOT0 default LOW; set HIGH with a jumper between CN11 pins 5 and 7. 5V_USB_STLK (CN12 pin 8) is the raw ST-LINK USB 5 V that rises before the board 5 V. PA13/PA14 are shared with SWD — avoid as GPIO. "Or" pins are chosen by solder bridges (motor-control table: PE6/BKIN2 SB10 ON/SB22 OFF; PE15/BKIN1 SB38 ON/SB37 OFF; PA4/DAC SB77 ON/SB59 OFF; PE8/TIM1_CH1N SB47 ON/SB43 OFF; PA1 and PC1 RMII pins need SB80/SB84 OFF to be free). Clock/oscillator morpho pins: CN11 pin 29 = PH0 (external clock in), pin 25 = PC14 (external LSE clock in).
