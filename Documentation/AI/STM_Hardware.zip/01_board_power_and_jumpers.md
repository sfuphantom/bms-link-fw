# NUCLEO-H755ZI-Q — Board: power, jumpers, SMPS/LDO config

Scope: the dev board only (ST board ref **MB1363**, variant H755ZIQ, revisions C01 / D01; sold as order code NUCLEO-H755ZI-Q, product ids NUH755ZIQ$AT1/$AT2). Source: UM2408 Rev 6. The target MCU is **STM32H755ZIT6** (dual Cortex-M7 + M4, LQFP144, 2 MB flash, internal SMPS, crypto). Board has Ethernet (RJ45), Micro-AB USB OTG, on-board **STLINK-V3E** debugger, ST Zio (Arduino Uno V3 superset) + ST morpho headers. NUCLEO-H745ZI-Q/H7A3ZI-Q share the PCB but differ (H7A3 has no Ethernet) — ignore their rows.

Conventions: "Jumper JPx ON" = fitted; "SBx ON" = solder bridge closed (or 0 ohm); OFF = open. Default states are shown in **bold** in the original PDF but bold was lost in text extraction; defaults below are those stated in prose.

## Board hardware block summary (from block diagram)
Two parts: **ST-LINK part** (STM32F723IEK6 "STLINK-V3E", Micro-B USB CN1) and **MCU part** (STM32H755, Zio CN7/8/9/10, morpho CN11/12, 3 LEDs, B1 user, B2 reset, Micro-AB USB CN13, RJ45 CN14). Links between them: SWD, VCP UART (USART3 PD8/PD9), MCO clock (8 MHz), NRST. Ethernet goes MCU --RMII--> LAN8742A PHY (U15) -> RJ45.

## Power input options (choose with JP2)
JP2 is a 2x4 header selecting the 5 V source feeding the board. Pin pairs:

| JP2 jumper | Source | Connector/pin | Voltage | Max current | Notes |
|---|---|---|---|---|---|
| pins 1-2 (STLK) **default** | ST-LINK USB CN1 (U5V) from PC | CN1 | 5 V | 500 mA (negotiated) | Board powers only after USB enumeration succeeds |
| pins 3-4 (VIN) | External 7-11 V | CN8 pin 15 / CN11 pin 24 | 7-11 V only | 800 mA @7 V; 450 mA for 7<VIN<9 V; 250 mA for 9<VIN<11 V | Goes through on-board 5 V regulator (U12) |
| pins 5-6 (EXT) | External 5 V | CN11 pin 6 (5V_EXT) | 4.75-5.25 V | 500 mA | |
| pins 7-8 (CHGR) | USB charger on CN1 | CN1 | 5 V | not specified | **ST-LINK NOT powered -> no debug/programming** |
| (no JP2; direct 3.3 V) | External 3.3 V | CN8 pin 7 / CN11 pin 16 | 3.0-3.6 V | not specified | **ST-LINK NOT powered -> no debug** |

External supplies must be SELV, limited power, EN 62368-1 compliant.

### USB enumeration behavior (PC power, JP2 1-2)
- Before enumeration the PC gives only 100 mA, so only the ST-LINK circuit is powered.
- During enumeration the board requests 500 mA (power switch U2 gated by PWR_ENn from the ST-LINK MCU). On success (SetConfiguration) U2 switches ON, **green LD5 (PWR) lights** and the MCU part + shield can draw up to 500 mA. If the host cannot supply it, enumeration fails, U2 stays OFF, LD5 stays OFF -> use an external supply.
- U2 current-limits; overcurrent >500 mA lights **red LD6**.
- Manual inconsistency: section 7.4.6 says 300 mA is requested at enumeration; 7.4.1 says 500 mA. Design for 500 mA budget but expect possible rejection.

### Debugging while powered from VIN or EXT — mandatory power sequence
1. Fit JP2 5-6 (EXT) or 3-4 (VIN). 2. Connect external source. 3. Power it on (7<VIN<11 V, or 5 V). 4. Confirm LD5 green ON. 5. THEN plug PC USB into CN1.
Wrong order risks USB (U5V) powering the board first: >300 mA draw can damage/limit the PC port, or enumeration is rejected and the board stays unpowered.

### Power outputs
When powered by USB, VIN or EXT: 5 V available on CN8 pin 9 / CN11 pin 18 for shields. 3.3 V on CN8 pin 7 / CN11 pin 16 is usable as output, limited by regulator U11 (**1300 mA max**).

## Other power-related jumpers
- **JP4 (IDD)**: ON (default) = MCU powered. Remove jumper and insert an ammeter to measure MCU current (no ammeter -> MCU unpowered). VDD also feeds level shifters U1/U10 (debug/VCP translation): for very-low-power measurement set pull-up/pull-down in software on PA13, PB3, PD8. On **Rev C01** boards VDD_MCU also feeds the Ethernet PHY U15, debug level shifters and pull-ups, so Standby IDD can't be measured unless you remove R4,R43-R53,R59,R64,U1,U10,U15,SB72 (kills Ethernet and 1.8 V debug). **Rev D01** fixed this (IDD jumper wiring, added SB13 to bypass U1) — "no limitation".
- **JP5 (VDD_MCU select)**: pins 1-2 = VDD_MCU 3.3 V (default); pins 2-3 = 1.8 V. If 1.8 V used, ST-LINK level shifters handle debug. Check JP5 before first power-up.
- **JP1 (STLK_RST)**: ON = ST-LINK held in reset (all its GPIOs high-Z, lets an external debugger on CN5 take over; also saves power). OFF (default) = no effect.
- **JP3 (T_NRST)**: ON (default) = board NRST connected to ST-LINK reset control; OFF = disconnected.
- JP6/JP7 (Ethernet RMII TXD1 / MDIO): must be ON when using Ethernet (see file 04). JP8 = USB power-enable routing (ON for H755).
- **VDDA/VREF+ (R40)**: R40 ON (default) ties VDDA and VREF+ to VDD. Remove R40 to feed external VREF+ via Zio CN7 pin 6 (AREF).
- **IOREF** selected by SB24/SB13/SB14: (OFF,OFF,ON)=VDD_MCU; (OFF,ON,OFF)=3V3_PER (Rev C only); (ON,OFF,OFF)=3V3.
- VBAT: SB83 ON connects VBAT to VDD_MCU.
- SB1 (3V3_PER, Rev C only) and SB2 (3.3 V regulator ST1L05CPU33R output) — ON connects them to the 3.3 V rail.

## Internal SMPS / LDO supply configuration  (CRITICAL — must match firmware)
The STM32H755 core supply (VCORE) can come from 4 configurations; hardware is set with solder bridges/resistors (X = fitted/ON, - = not fitted):

| | Config 1: LDO only | **Config 2: SMPS direct (DEFAULT)** | Config 3: SMPS + LDO cascaded | Config 4: Bypass (ext VCORE) |
|---|---|---|---|---|
| SMPS | OFF | ON | ON | OFF |
| LDO | ON | OFF | ON | OFF |
| SB25 | X | - | - | - |
| R33 | X | - | - | X |
| SB74 | X | - | - | X |
| C58 / C54 | 2.2 uF | 100 nF | 2.2 uF | 100 nF |
| SB92 | - | X | X | - |
| SB79 | - | X | X | - |
| SB75 | - | X | - | X |
| SB76 | - | X | X | X |
| R35 | - | X | - | - |
| R34 | - | - | X | - |
| SB97 | - | - | - | X |
| SB95 | - | - | - | X |

**Datasheet implication:** with the SMPS directly supplying VCORE (the board default), **VOS0 (480 MHz M7 / 240 MHz M4) is NOT available**; max is VOS1 = **400 MHz M7 / 200 MHz M4**. VOS0 requires the LDO as VCORE source (Config 1, hardware rework).

**Deadlock warning:** the firmware's supply setting must match the hardware. A mismatch makes the MCU unreachable (ST-LINK cannot connect after reset). In `main.c` `SystemClock_Config()`:
- Default (Config 2, direct SMPS): `HAL_PWREx_ConfigSupply(PWR_DIRECT_SMPS_SUPPLY);`
- LDO hardware (Config 1): `HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);`

**Recovery from mismatch deadlock:** (1) power off; (2) wire CN11 BOOT0 pin (CN11 pin 7) to VDD (CN11 pin 5 = 3V3_VDD; the 1-2 header notes BOOT0 high via jumper between CN11 pins 5 and 7); (3) power on -> boots system-memory bootloader instead of user flash; (4) connect with STM32CubeProgrammer; (5) erase user flash; (6) power off, remove wire; board recovers.

## External SMPS option (CN6 footprint, unpopulated)
Optional external module (e.g. ST1PS02D1QTR) on CN6: pin1 3V3_VDD; pin2 SMPS_V1 (PG8, D1 voltage select; needs SB34 ON/SB31 OFF); pin3 VOUTVDD (ext 3.3 V for MCU); pin4 SMPS_EN (PG9; SB35 ON/SB41 OFF); pin5 1V2_VOUTCORE (ext 1.2 V VCORE into VCAP); pin6 SMPS_SW (PG10; SB33 ON/SB30 OFF); pin7 GND; pin8 SMPS_PG (PG12; SB42 ON/SB45 OFF). These GPIOs (PG8,PG9,PG10,PG12) are also Zio D50, D8, D49, D7.

## Safety / handling (brief)
Board is ESD-sensitive; don't touch connections while powered; sharp header pins; not for children; **USB CN13 cannot power the board** — power the board BEFORE connecting a cable to CN13 (otherwise current injection into STM32 I/Os).
