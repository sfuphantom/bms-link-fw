# NUCLEO-H755ZI-Q — Board: clocks, USB, Ethernet, motor control, solder bridges

Source: UM2408 Rev 6 (7.9-7.14), H755 rows only. MCU STM32H755ZIT6. Default SB/JP state = stated in prose; bold defaults were lost in extraction, so "default" is marked only where the text says so.

## Clocks
**HSE (main, 4-48 MHz capable) — four options:**
1. **MCO from ST-LINK (default):** 8 MHz into PH0/OSC_IN. SB72 ON, SB71 OFF, SB3 & SB4 OFF. (Frequency may change with ST-LINK firmware — RN0093.) In firmware use HSE **bypass** mode at the 8 MHz.
2. On-board crystal X2: 25 MHz, 6 pF, 20 ppm (NDK NX2016SA-25MHz). SB71 & SB90 OFF, SB3 & SB4 ON, C74 & C76 fitted 5.1 pF, SB72 OFF.
3. External oscillator on CN11 pin 29 (PH0): SB71 ON, SB72 OFF, SB3/SB4 removed.
4. HSE unused (PH0/PH1 = GPIO): SB71 & SB90 ON, SB72 OFF, SB3/SB4 removed.
**LSE (32.768 kHz):** on-board crystal X3 (default; NDK NX3215SA, 6 pF, 20 ppm). Or external clock on CN11 pin 25 (PC14): SB66 & SB67 ON, R41 & R42 removed. Or unused (PC14/PC15 GPIO): same SB66/SB67 ON, R41/R42 removed.
Crystal-less USB: MCU can use HSI48 for USB FS (datasheet).

## USB (user USB, CN13 Micro-AB, OTG full speed)
- Uses **PA11 (DM), PA12 (DP)** via the MCU's internal FS PHY (datasheet names: `OTG_FS_DM/DP`, AF10). PA9 = VBUS sense, PA10 = ID (ID not used on board — ESD part USBLC6-2SC6), PA8 = SOF test point TP4. PA11/PA12 also offer FDCAN1_RX/TX (AF9) if not used for USB.
- VBUS power switch U18 enable = **PD10** (JP8 ON on H745/H755 to connect it), overcurrent flag = **PG7** (SB100 ON).
- LD8 green: VBUS present / host power ON; LD7 red: overcurrent in host mode.
- **CN13 cannot power the board — power board first, then plug USB** (current injection risk). Use external power when using USB host/OTG.
- USB pin solder bridges (USB-connector config | morpho config): PA9 SB21 ON | OFF; PA10 SB29 ON | OFF; PA11 SB26 ON | OFF; PA12 SB27 ON | OFF; PD10 power-enable: JP8 ON (H745/H755) | OFF; PF10 power-enable: SB91 OFF in both H755 configs; PG7 overcurrent SB100 ON | OFF. SB26/SB27 OFF frees PA11/PA12 as GPIO on morpho.
- The board only exposes the full-speed USB on PA11/PA12; no external ULPI (high-speed) PHY is described in the manual.

## Ethernet (RJ45 CN14, 10/100 Mbit)
- PHY **LAN8742A-CZ-TR (U15)**, RMII interface to MCU; PHY supplies the 50 MHz RMII_REF_CLK to the MCU.
- **JP6 and JP7 must be ON** when using Ethernet.
- RMII pin map (all must stay assigned to Ethernet when used; solder bridges default ON for H755): PA1 RMII_REF_CLK (SB80); PA2 RMII_MDIO (JP7; conflicts Zio A8); PC1 RMII_MDC (SB84); PA7 RMII_CRS_DV (SB52); PC4 RMII_RXD0 (SB63); PC5 RMII_RXD1 (SB48); PG11 RMII_TX_EN (SB36); PG13 RMII_TXD0 (SB46); PB13 RMII_TXD1 (JP6 ON & SB8 OFF for Ethernet; JP6 OFF & SB8 ON to give PB13 to Zio D18). To free these pins for Zio/morpho use set their SB OFF.
- PHY reset: SB98 ON connects MCU NRST to PHY. HAL peripheral: ETH with `ETH_RMII_*` AF11 (PA1/PA2/PC1/PA7/PC4/PC5/PG11/PG13/PB13 all AF11; see 07b).
- Rev C01 only: to reach low-power IDD the PHY must be in power-down (LAN8742A basic control register 0x00, bit 11 = 1) or remove SB13.

## Motor control shield compatibility
X-NUCLEO-IHM09M1, IHM07M1 (L6230), IHM08M1 (STL220N6F7): fit CN11 and CN12 morpho headers and set bridges: PE6 morpho CN12 pin 14 (BKIN2) SB10 ON/SB22 OFF; PE15 morpho CN12 pin 28 (BKIN1) SB38 ON/SB37 OFF; PA4 morpho CN12 pin 29 (DAC) SB77 ON/SB59 OFF; PE8 morpho CN12 pin 30 (TIM1_CH1N) SB47 ON/SB43 OFF; PA1 (RMII ref clk) SB80 OFF; PC1 (RMII MDC) SB84 OFF (Ethernet is then unusable).

## Other solder-bridge table (selected, non-obvious)
| Bridge(s) | State -> effect |
|---|---|
| SB103/SB104 | ON: PD8/PD9 to morpho CN11/CN12 (then SB16,SB17,SB15,SB94 must be OFF); OFF: disconnected |
| SB20 (SDMMC_D0), SB9 (SDMMC_D1) | ON: PC8/PC9 to morpho CN12; OFF: disconnected to avoid SDMMC stub |
| SB54/SB65 | LD1: (ON,OFF)=PB0, (OFF,ON)=PA5/D13, (OFF,OFF)=none, (ON,ON) forbidden |
| R74 / R75 | ON = LD2(PE1) / LD3(PB14) connected |
| SB56/SB57 (D11) | H755: (OFF,ON): D11 = PB5 (SPI1_MOSI/TIM3_CH2); H7A3 differs |
| SB73/SB70 (A6) | H755: (ON,OFF): A6 = PF6 |
| SB93/SB58 (A7) | H755: (ON,OFF): A7 = PF10 |
| SB78 (A8) | OFF for H745/H755 (PA2 free of A8) — A8 is "NC by default" because PA2 is RMII_MDIO |
| SB69,SB40 (ADC A4/A5) / SB62,SB39 (I2C A4/A5) | (ON,ON,OFF,OFF): A4/A5 = PC2_C/PF11 analog; (OFF,OFF,ON,ON): A4/A5 = PB9/PB8 I2C |
| SB81/SB82 (B1) | see file 02 |
| SB89 | PA0 to Zio CN10 pin 29 (ON/OFF) |
| SB83 | VBAT to VDD_MCU |
| SB98 | MCU NRST to Ethernet PHY |
| RMII signals: SB80,SB84,JP7,SB63,SB48,SB46,SB36 | ON = Ethernet use, pins must not be used on Zio/morpho; OFF = free GPIO. "No default for RMII signals" in manual footnote — H745/H755 boards ship with Ethernet ON |
