# NUCLEO-H755ZI-Q — Board: debug/programming (STLINK-V3E), VCP, LEDs, buttons

Source: UM2408 Rev 6 (sections 6-7.7, 7.10) + DB3171. Target MCU: STM32H755ZIT6.

## On-board STLINK-V3E
- Integrated debugger/programmer (MCU STM32F723IEK6, labelled "STLINK-V3E"); no external probe required. USB 2.0 high-speed-compatible, Micro-B connector **CN1**.
- Interfaces: SWD, JTAG, SWV (serial wire viewer), Virtual COM port (VCP), mass storage (drag-drop flash), debug port. USB re-enumeration capability. Appears as a USB composite device (VID 0x0483; PID 0x374E = V3 without bridge functions, 0x374F = with bridge functions).
- JTAG/SWD target voltage 3 V to 3.6 V on the interface with 5 V-tolerant inputs.
- Windows 7/8 need the ST-LINK driver; Windows 10, Linux, macOS do not. If board is connected before driver install, manually re-associate "Unknown" USB devices in Device Manager.
- Keep ST-LINK firmware updated (in-place upgrade over USB, tool from st.com).
- Programs both cores' flash through the single SWD/JTAG port; the datasheet debug infrastructure allows debugging **one core at a time or both in parallel** (CoreSight; 4 KB embedded trace FIFO).

### Debug-related MCU pins
| Signal | MCU pin | Notes |
|---|---|---|
| SWDIO / JTMS | PA13 | Shared with ST-LINK; avoid using as GPIO |
| SWCLK / JTCK | PA14 | Shared with ST-LINK; avoid using as GPIO |
| SWO / TRACESWO / JTDO | PB3 | Connected to ST-LINK SWO and CN5 pin 8 (SB49/SB50 selects, see below). Also Zio D23 (CN7 pin 15) |
| NRST | NRST | B2 reset button; JP3 links to ST-LINK |
| VCP (USART3) | PD8 = TX, PD9 = RX | default routed to ST-LINK (SB16, SB17 ON) |
| MCO clock in | PH0/OSC_IN | 8 MHz from ST-LINK by default (SB72 ON) |

SWO routing (SB49, SB50): ON,ON = PB3 to ST-LINK SWO **and** Zio CN7 pin 15; OFF,ON = ST-LINK/CN5 only; ON,OFF = PB3 to Zio pin 15 only (I2S_B_CK/SPI_B_SCK usable); OFF,OFF = PB3 unconnected.

## Programming/debugging options
1. **Embedded ST-LINK** (normal): jumper JP2 correct (see file 01), connect PC USB Type-A -> Micro-B to **CN1**.
2. **External debug tool on CN5 (MIPI-10 / STDC14 footprint)**, two ways:
   - Leave ST-LINK running: power it first until COM LED LD4 lights red, then connect the external tool.
   - Hold ST-LINK in reset: fit **JP1 (STLK_RST)**; all ST-LINK GPIOs go high-Z; then use external tool.

### CN5 pinout (MIPI-10 pin / STDC14 pin)
| MIPI10 | STDC14 | Signal | Meaning |
|---|---|---|---|
| - | 1,2 | NC | reserved |
| 1 | 3 | T_VCC | target VCC |
| 2 | 4 | T_SWDIO (T_JTMS) | SWDIO or JTAG TMS |
| 3 | 5 | GND | |
| 4 | 6 | T_SWCLK (T_JCLK) | SWCLK or JTAG TCK |
| 5 | 7 | GND | |
| 6 | 8 | T_SWO (T_JTDO) | SWO or JTAG TDO |
| 7 | 9 | T_JRCLK | JTAG RTCK, specific use only |
| 8 | 10 | T_JTDI | JTAG TDI, external tools only |
| 9 | 11 | GNDDetect | plug detect |
| 10 | 12 | T_NRST | target reset |
| - | 13 | T_VCP_RX | VCP RX (must be the UART dedicated to the bootloader) |
| - | 14 | T_VCP_TX | VCP TX |

## Virtual COM port (USART3)
USART3 on PD8 (TX) / PD9 (RX) is wired through the ST-LINK to the PC as a COM port (default). Solder-bridge options:

| Pin | Function | Virtual COM port (DEFAULT) | Arduino D0/D1 | ST morpho |
|---|---|---|---|---|
| PD8 | USART3_TX | SB103 OFF, SB16 ON, SB15 OFF | SB103 OFF, SB16 OFF, SB15 ON | SB103 ON, SB16 OFF, SB15 OFF |
| PD9 | USART3_RX | SB104 OFF, SB17 ON, SB94 OFF | SB104 OFF, SB17 OFF, SB94 ON | SB104 ON, SB17 OFF, SB94 OFF |

Alternate VCP wiring group (SB16,SB17,SB12,SB64): (ON,ON,OFF,OFF) = PD8/PD9; (OFF,OFF,ON,ON) = PB6/PB7 (then PB6/PB7 unusable on morpho); all OFF = VCP disconnected. Arduino USART group (SB11,SB96,SB15,SB94): (ON,ON,OFF,OFF) = D1/D0 on PB6/PB7 (this is the *default Zio D0/D1 mapping* per the pin table: D1 = PB6 LPUART1_TX, D0 = PB7 LPUART1_RX); (OFF,OFF,ON,ON) = D1/D0 on PD8/PD9; all OFF = disconnected. SB13 (not fitted by default on Rev D01) bypasses U1 level shifter between T_VCP_TX and STLK_VCP_RX.
(The Zio table lists D0/D1 as **LPUART1** on PB7/PB6; the VCP is **USART3** on PD9/PD8.)

## LEDs
| LED | Colour | Connected to | Notes |
|---|---|---|---|
| LD1 | green | **PB0** (SB54 ON, SB65 OFF — default) or PA5/Zio D13 (SB65 ON, SB54 OFF) | SB54 ON+SB65 ON forbidden. Active HIGH (LED on when pin high). |
| LD2 | yellow | **PE1** (R74 ON) | active high |
| LD3 | red | **PB14** (R75 ON) | active high; conflicts with Zio D65 (PB14) — remove R75 if D65 used |
| LD4 COM | red/green/orange | ST-LINK status | see below |
| LD5 PWR | green | 5 V power good | MCU part powered & +5 V on CN8 pin 9 / CN11 pin 18 |
| LD6 | red | USB overcurrent (>500 mA) on CN1 | external supply needed |
| LD7 | red | USB FS overcurrent on CN13 (host mode, 5 V enabled) | |
| LD8 | green | USB VBUS present on CN13 / power switch ON in host mode | |

LD4 COM states: slow-blink red or off = power-on before USB init; fast-blink red/off = after first PC<->ST-LINK enumeration; red ON = PC<->ST-LINK init complete; green ON = successful target comm init; blinking red/green = communicating with target; green ON = comm finished OK; orange ON = comm failure.

## Buttons
- **B1 USER (blue)**: PC13 by default (SB82 ON, SB81 OFF; tamper/wake support). Alternative PA0 (SB81 ON, SB82 OFF; wake-up pin; set SB82 OFF if Zio is used). Both OFF = not connected. PA0 is also Zio D32 via SB89 ON (CN10 pin 29).
- **B2 RESET (black)**: tied to NRST; resets the MCU.
- Pre-programmed demo: after power-up LD5 green + LD4 light and LD3 red blinks; pressing B1 changes the blink frequency of LD1-LD3.
