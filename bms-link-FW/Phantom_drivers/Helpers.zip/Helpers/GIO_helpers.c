/*
 * GIO_helpers.c
 *
 *  Created on: Jul 24, 2026
 *      Author: tanjo
 */

#include "GIO_helpers.h"
#include "Cpu_stubs.h"
#include "PhantomHelpers.h"
#include "PhantomTimers.h"

/*--------------------------------------------------------------------------
 * Pins
 *------------------------------------------------------------------------*/
GioLevel_t gio_read(const GioName_t pin)
{
    return gioStub_read(pin);
}

void gio_write(const GioName_t pin, const GioLevel_t level)
{
    gioStub_write(pin, level);
}

GioLevel_t gio_toggle(const GioName_t pin)
{
    gioStub_toggle(pin);
    return gioStub_read(pin);
}

void gio_setDirection(const GioName_t pin, const GioDir_t dir)
{
    gioStub_setDirection(pin, dir);
}

void gio_writeMany(const GioName_t * const pins, const size_t count, const GioLevel_t level)
{
    gioStub_writeMany(pins, count, level);
}

/*--------------------------------------------------------------------------
 * Output helpers
 *------------------------------------------------------------------------*/
static GioLevel_t opposite(const GioLevel_t level)
{
    return (level == GIO_HIGH) ? GIO_LOW : GIO_HIGH;
}

bool gio_writeIf(const GioName_t pin, const GioLevel_t level, const bool condition)
{
    if (condition) { gio_write(pin, level); }
    return condition;
}

void gio_pulseN(const GioName_t pin, const uint32_t count, const GioLevel_t level,
                const ticks_t width, const ticks_t gap)
{
    uint32_t i;
    for (i = 0; i < count; i++) {
        gio_write(pin, level);
        delay_ticks(width);
        gio_write(pin, opposite(level));

        if (i + 1U < count) { delay_ticks(gap); }
    }
}

void gio_toggleN(const GioName_t pin, const uint32_t count, const ticks_t halfPeriod)
{
    uint32_t i;
    for (i = 0; i < count; i++) {
        (void)gio_toggle(pin);

        if (i + 1U < count) { delay_ticks(halfPeriod); }
    }
}

bool gio_toggleEvery(Periodic_t * const p, const GioName_t pin)
{
    if (!periodic_due(p)) { return false; }

    (void)gio_toggle(pin);
    return true;
}

void gio_pwm(const GioName_t pin, const ticks_t period, const float duty, ticks_t * const periodStart)
{
    const bool high = pwmSignalGen(period, duty, periodStart);
    gio_write(pin, high ? GIO_HIGH : GIO_LOW);
}

void gio_timedPulse_start(GioTimedPulse_t * const p, const GioName_t pin, const GioLevel_t level, const ticks_t width)
{
    p->pin   = pin;
    p->level = level;

    gio_write(pin, level);
    timeout_start(&p->timer, width);
}

bool gio_timedPulse_update(GioTimedPulse_t * const p)
{
    if (!p->timer.active)            { return false; }
    if (!timeout_expired(&p->timer)) { return true; }

    gio_write(p->pin, opposite(p->level));
    timeout_cancel(&p->timer);
    return false;
}

/*--------------------------------------------------------------------------
 * Input helpers
 *------------------------------------------------------------------------*/
ticks_t gio_timeAtLevel(TrueTimer_t * const t, const GioName_t pin, const GioLevel_t level)
{
    ticks_t duration = 0;

    (void)trueTimer_update(t, gio_read(pin) == level, &duration);
    return duration;
}

void gio_watchInit(GioWatch_t * const w, const GioName_t pin)
{
    w->pin  = pin;
    w->last = gio_read(pin);
}

Edge_t gio_watch(GioWatch_t * const w)
{
    const GioLevel_t before = w->last;
    const GioLevel_t now    = gio_read(w->pin);

    w->last = now;

    if (now == before)   { return EDGE_NONE; }
    if (now == GIO_HIGH) { return EDGE_RISING; }
    return EDGE_FALLING;
}

void gio_debounceInit(Debouncer_t * const d, const GioName_t pin)
{
    debounce_init(d, gio_read(pin) == GIO_HIGH);
}

Edge_t gio_debounce(Debouncer_t * const d, const GioName_t pin, const ticks_t hold)
{
    return debounce_time(d, gio_read(pin) == GIO_HIGH, hold);
}

bool gio_waitStable(const GioName_t pin, const GioLevel_t level, const ticks_t stable, const ticks_t timeout)
{
    const bool want = (level == GIO_HIGH);
    Debouncer_t d;
    Timeout_t   t;

    debounce_init(&d, !want);       /* start on the other level, so it has to see the change */
    timeout_start(&t, timeout);

    while (d.state != want) {
        (void)debounce_time(&d, gio_read(pin) == GIO_HIGH, stable);

        if (timeout != 0U && timeout_expired(&t)) { return (d.state == want); }
    }
    return true;
}

/*--------------------------------------------------------------------------
 * Send bytes
 *------------------------------------------------------------------------*/
static void waitUntilOffset(const ticks_t start, const ticks_t offset)
{
    while (!hasTimeElapsed(start, offset)) { }
}

void gio_serialInit(GioSerial_t * const s, const GioName_t data, const GioName_t clock,
                    const uint32_t bitsPerSecond, const bool msbFirst)
{
    s->data     = data;
    s->clock    = clock;
    s->bitTicks = (bitsPerSecond == 0U) ? 0U : GIO_BITRATE_TO_TICKS(bitsPerSecond);
    s->msbFirst = msbFirst;

    gio_setDirection(data, GIO_OUTPUT);
    if (clock == GIO_NONE) {
        gio_write(data, GIO_HIGH);
    } else {
        gio_setDirection(clock, GIO_OUTPUT);
        gio_write(clock, GIO_LOW);
    }
}

void gio_sendByte(const GioSerial_t * const s, const uint8_t value)
{
    const bool    framed  = (s->clock == GIO_NONE);
    const ticks_t start   = timer_tic_tick();
    ticks_t       slotEnd = 0;      /* every bit is timed from start, so the error does not add up */
    uint8_t       i;

    if (framed) {                   /* start bit */
        gio_write(s->data, GIO_LOW);
        slotEnd += s->bitTicks;
        waitUntilOffset(start, slotEnd);
    }

    for (i = 0; i < 8U; i++) {
        const uint8_t bitIdx = s->msbFirst ? (uint8_t)(7U - i) : i;

        gio_write(s->data, (((value >> bitIdx) & 1U) != 0U) ? GIO_HIGH : GIO_LOW);

        if (!framed) {
            waitUntilOffset(start, slotEnd + (s->bitTicks / 2U));
            gio_write(s->clock, GIO_HIGH);
        }

        slotEnd += s->bitTicks;
        waitUntilOffset(start, slotEnd);

        if (!framed) { gio_write(s->clock, GIO_LOW); }
    }

    if (framed) {                   /* stop bit */
        gio_write(s->data, GIO_HIGH);
        slotEnd += s->bitTicks;
        waitUntilOffset(start, slotEnd);
    }
}

void gio_sendBytes(const GioSerial_t * const s, const uint8_t * const bytes, const size_t count)
{
    size_t i;
    for (i = 0; i < count; i++) {
        gio_sendByte(s, bytes[i]);
    }
}

/*--------------------------------------------------------------------------
 * Interrupts. One slot per name.
 *------------------------------------------------------------------------*/
static volatile uint32_t intCount[GIO_NAME_COUNT];
static GioCallback_t     intHandler[GIO_NAME_COUNT];

static bool nameOk(const GioName_t pin)
{
    return (unsigned int)pin < (unsigned int)GIO_NAME_COUNT;
}

bool gio_attach(const GioName_t pin, const GioCallback_t handler)
{
    if (!nameOk(pin)) { return false; }

    intHandler[pin] = handler;              /* first, so the interrupt finds it */
    if (!gioStub_irqEnable(pin)) {
        intHandler[pin] = NULL;
        return false;
    }
    return true;
}

void gio_detach(const GioName_t pin)
{
    if (!nameOk(pin)) { return; }

    gioStub_irqDisable(pin);
    intHandler[pin] = NULL;
}

uint32_t gio_takeInterrupts(const GioName_t pin)
{
    uint32_t irq;
    uint32_t count;

    if (!nameOk(pin)) { return 0U; }

    CRITICAL_ENTER(irq);
    count = intCount[pin];
    intCount[pin] = 0U;
    CRITICAL_EXIT(irq);

    return count;
}

#if defined(__TI_COMPILER_VERSION__)
#pragma WEAK(Debug_GIO_Notification)
#pragma WEAK(IMD_FAULT_GIO_Notification)
#endif
void WEAK_FN Debug_GIO_Notification(void)       { }
void WEAK_FN IMD_FAULT_GIO_Notification(void)   { }

static void oldHooks(const GioName_t pin)
{
    switch (pin) {
        case GIO_DEBUG_PIN:     Debug_GIO_Notification();     break;
        case GIO_IMD_FAULT_PIN: IMD_FAULT_GIO_Notification(); break;
        default: break;
    }
}

/* Called by the stub from the interrupt */
void gio_handleInterrupt(const GioName_t pin)
{
    if (!nameOk(pin)) { return; }

    intCount[pin]++;

    if (intHandler[pin] != NULL) { intHandler[pin](pin); }
    else                         { oldHooks(pin); }
}
