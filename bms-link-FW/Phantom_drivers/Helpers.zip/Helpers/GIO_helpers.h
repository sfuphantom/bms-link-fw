/*
 * GIO_helpers.h
 *
 *  Created on: Jul 24, 2026
 *      Author: tanjo
 */

#ifndef PHANTOM_DRIVERS_INCLUDE_GIO_HELPERS_H_
#define PHANTOM_DRIVERS_INCLUDE_GIO_HELPERS_H_

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include "GIO_stubs.h"          /* GioName_t, GioLevel_t, GioDir_t */
#include "PhantomTimers.h"

/*--------------------------------------------------------------------------
 * Pins. Only GioName_t is used, which pin that is lives in PhantomPinAlloc.c.
 * A bad pin is ignored (reads as GIO_LOW).
 *------------------------------------------------------------------------*/
GioLevel_t gio_read(const GioName_t pin);
void       gio_write(const GioName_t pin, const GioLevel_t level);
GioLevel_t gio_toggle(const GioName_t pin);                 /* returns the new level */
void       gio_setDirection(const GioName_t pin, const GioDir_t dir);

/* Pins on the same port change in the same write, pins on different ports one after the other */
void gio_writeMany(const GioName_t * const pins, const size_t count, const GioLevel_t level);

/*--------------------------------------------------------------------------
 * Output helpers
 *------------------------------------------------------------------------*/
bool gio_writeIf(const GioName_t pin, const GioLevel_t level, const bool condition);   /* returns condition */

/* level for width, then back to the opposite level; gap is only between pulses */
void gio_pulseN(const GioName_t pin, const uint32_t count, const GioLevel_t level,
                const ticks_t width, const ticks_t gap);
#define gio_pulse(pin, level, width)    gio_pulseN((pin), 1U, (level), (width), 0U)

void gio_toggleN(const GioName_t pin, const uint32_t count, const ticks_t halfPeriod);

/* Non-blocking. Start the Periodic_t with periodic_init. Returns true when it toggled. */
bool gio_toggleEvery(Periodic_t * const p, const GioName_t pin);

void gio_pwm(const GioName_t pin, const ticks_t period, const float duty, ticks_t * const periodStart);

/* Non-blocking pulse: start it, then call update often. update returns true while the pulse is on. */
typedef struct {
    GioName_t  pin;
    GioLevel_t level;
    Timeout_t  timer;
} GioTimedPulse_t;

void gio_timedPulse_start(GioTimedPulse_t * const p, const GioName_t pin, const GioLevel_t level, const ticks_t width);
bool gio_timedPulse_update(GioTimedPulse_t * const p);

/*--------------------------------------------------------------------------
 * Input helpers
 *------------------------------------------------------------------------*/
/* Non-blocking: call it often. Returns how long the pin has been at level (0 if it is not).
 * Start the TrueTimer_t as {0}. */
ticks_t gio_timeAtLevel(TrueTimer_t * const t, const GioName_t pin, const GioLevel_t level);

/* Did the pin change since the last gio_watch call */
typedef struct {
    GioName_t  pin;
    GioLevel_t last;
} GioWatch_t;

void   gio_watchInit(GioWatch_t * const w, const GioName_t pin);
Edge_t gio_watch(GioWatch_t * const w);                     /* EDGE_NONE / EDGE_RISING / EDGE_FALLING */

void   gio_debounceInit(Debouncer_t * const d, const GioName_t pin);
Edge_t gio_debounce(Debouncer_t * const d, const GioName_t pin, const ticks_t hold);

/* Blocking: true if the pin stayed at level for stable before timeout ran out (timeout 0 = forever) */
bool gio_waitStable(const GioName_t pin, const GioLevel_t level, const ticks_t stable, const ticks_t timeout);

/*--------------------------------------------------------------------------
 * Send bytes with software timing.
 * clock == GIO_NONE : serial with start and stop bit (8N1), data idles high
 * otherwise         : data changes while clock is low, clock idles low
 *------------------------------------------------------------------------*/
#define GIO_BITRATE_TO_TICKS(bitsPerSecond)  (((ticks_t)TICKS_PER_US * 1000000U) / (bitsPerSecond))

typedef struct {
    GioName_t data;
    GioName_t clock;
    ticks_t   bitTicks;
    bool      msbFirst;
} GioSerial_t;

void gio_serialInit(GioSerial_t * const s, const GioName_t data, const GioName_t clock,
                    const uint32_t bitsPerSecond, const bool msbFirst);
void gio_sendByte(const GioSerial_t * const s, const uint8_t value);
void gio_sendBytes(const GioSerial_t * const s, const uint8_t * const bytes, const size_t count);

/*--------------------------------------------------------------------------
 * Interrupts (pins with an interrupt only). Edge and priority are still set in HALCoGen.
 * The handler runs in the interrupt, keep it short. Without a handler the
 * interrupts are only counted.
 * gio_handleInterrupt (called by the stub) is declared in GIO_stubs.h.
 *------------------------------------------------------------------------*/
typedef void (*GioCallback_t)(const GioName_t pin);

bool     gio_attach(const GioName_t pin, const GioCallback_t handler);  /* handler may be NULL */
void     gio_detach(const GioName_t pin);
uint32_t gio_takeInterrupts(const GioName_t pin);                       /* how many since the last call */

/* Old per-pin hooks. They are weak and still called when no handler is attached. */
void Debug_GIO_Notification(void);
void IMD_FAULT_GIO_Notification(void);

#endif /* PHANTOM_DRIVERS_INCLUDE_GIO_HELPERS_H_ */
