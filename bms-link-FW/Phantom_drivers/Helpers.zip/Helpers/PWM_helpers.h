/*
 * PWM_helpers.h
 *
 *  PWM by name (PwmName_t, see PhantomPinAlloc.h). All return false if the
 *  name is not a PWM of the right kind (output / input) or there is no signal.
 */

#ifndef PWM_HELPERS_H_
#define PWM_HELPERS_H_

#include <stdbool.h>
#include "PWM_stubs.h"

bool pwm_enable(const PwmName_t pwm, const bool on);                        /* output */
bool pwm_set(const PwmName_t pwm, const float dutyPct, const float freqHz); /* output */
bool pwm_setDuty(const PwmName_t pwm, const float dutyPct);                 /* output, keeps the frequency */

bool pwm_readDuty(const PwmName_t pwm, float * const dutyPct);              /* input or output */
bool pwm_readFreq(const PwmName_t pwm, float * const freqHz);               /* input or output */

#endif /* PWM_HELPERS_H_ */
