/*
 * PWM_helpers.c
 */

#include "PWM_helpers.h"

#define US_PER_SECOND   1000000.0f

bool pwm_enable(const PwmName_t pwm, const bool on)
{
    return on ? pwmStub_start(pwm) : pwmStub_stop(pwm);
}

bool pwm_set(const PwmName_t pwm, const float dutyPct, const float freqHz)
{
    PwmSignal_t sig;

    if (!(freqHz > 0.0f)) { return false; }

    sig.dutyPct  = dutyPct;
    sig.periodUs = US_PER_SECOND / freqHz;
    return pwmStub_write(pwm, &sig);
}

bool pwm_setDuty(const PwmName_t pwm, const float dutyPct)
{
    return pwmStub_setDuty(pwm, dutyPct);
}

bool pwm_readDuty(const PwmName_t pwm, float * const dutyPct)
{
    PwmSignal_t sig;

    if (!pwmStub_read(pwm, &sig)) { return false; }

    *dutyPct = sig.dutyPct;
    return true;
}

bool pwm_readFreq(const PwmName_t pwm, float * const freqHz)
{
    PwmSignal_t sig;

    if (!pwmStub_read(pwm, &sig) || !(sig.periodUs > 0.0f)) { return false; }

    *freqHz = US_PER_SECOND / sig.periodUs;
    return true;
}
