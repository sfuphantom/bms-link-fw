/*
 * CAN_stubs.c
 */

#include <string.h>
#include "CAN_stubs.h"
#include "Stub_Pins.h"

#if BOARD == BOARD_TMS570_HW

#include "can.h"
#include "reg_can.h"

#ifndef CAN_NODE
  #define CAN_NODE      canREG1
#endif

void canStub_init(void)
{
    canInit();
    canEnableErrorNotification(CAN_NODE);       /* bus-off, warning and parity interrupts */
}

bool canStub_isBoxValid(const CanBox_t box)
{
    const uint32_t hw = alloc_canHwBox(box);

    return (hw != CAN_HW_NO_BOX) && (canIsMessageBoxValid(CAN_NODE, hw) != 0U);
}

/* 1 = request set, 0 = box still sending. It sends the dlc set in HALCoGen. */
bool canStub_tx(const CanBox_t box, const uint8_t frame[CAN_MAX_DLC])
{
    const uint32_t hw = alloc_canHwBox(box);

    return (hw != CAN_HW_NO_BOX) && (canTransmit(CAN_NODE, hw, frame) != 0U);
}

/* canGetData: 0 = nothing new, 1 = ok, 3 = ok but an earlier frame was lost */
CanRx_t canStub_rx(const CanBox_t box, uint8_t frame[CAN_MAX_DLC])
{
    const uint32_t hw = alloc_canHwBox(box);

    if (hw == CAN_HW_NO_BOX) { return CAN_RX_NONE; }

    switch (canGetData(CAN_NODE, hw, frame)) {
        case 1U:  return CAN_RX_OK;
        case 3U:  return CAN_RX_LOST;
        default:  return CAN_RX_NONE;
    }
}

bool canStub_remote(const CanBox_t box)
{
    const uint32_t hw = alloc_canHwBox(box);

    return (hw != CAN_HW_NO_BOX) && (canSendRemoteFrame(CAN_NODE, hw) != 0U);
}

/* Clearing Init starts the recovery (129 x 11 recessive bits) */
void canStub_restart(void)
{
    CAN_NODE->CTL &= ~(uint32)1U;
}

uint32_t canStub_lastError(void)
{
    return canGetLastError(CAN_NODE);
}

/* HALCoGen callbacks: only forward */
void canMessageNotification(canBASE_t *node, uint32 messageBox)
{
    const CanBox_t box = alloc_canBox(messageBox);

    if ((node == CAN_NODE) && (box != CAN_NO_BOX)) { can_handle_message(box); }
}

void canErrorNotification(canBASE_t *node, uint32 notification)
{
    if (node == CAN_NODE) { can_handle_error(notification, (notification & canLEVEL_BUS_OFF) != 0U); }
}

#elif BOARD == BOARD_SIL

static uint8_t simTx[CAN_BOX_COUNT][CAN_MAX_DLC];
static bool    simTxNew[CAN_BOX_COUNT];
static uint8_t simRx[CAN_BOX_COUNT][CAN_MAX_DLC];
static bool    simRxNew[CAN_BOX_COUNT];
static bool    simRxLost[CAN_BOX_COUNT];

void canStub_init(void)
{
    memset(simTxNew, 0, sizeof(simTxNew));
    memset(simRxNew, 0, sizeof(simRxNew));
    memset(simRxLost, 0, sizeof(simRxLost));
}

bool canStub_isBoxValid(const CanBox_t box)
{
    return alloc_canHwBox(box) != CAN_HW_NO_BOX;
}

bool canStub_tx(const CanBox_t box, const uint8_t frame[CAN_MAX_DLC])
{
    if (!canStub_isBoxValid(box)) { return false; }

    memcpy(simTx[box], frame, CAN_MAX_DLC);     /* the box is never busy, a new frame replaces the old one */
    simTxNew[box] = true;
    return true;
}

CanRx_t canStub_rx(const CanBox_t box, uint8_t frame[CAN_MAX_DLC])
{
    CanRx_t result;

    if (!canStub_isBoxValid(box) || !simRxNew[box]) { return CAN_RX_NONE; }

    memcpy(frame, simRx[box], CAN_MAX_DLC);
    result = simRxLost[box] ? CAN_RX_LOST : CAN_RX_OK;
    simRxNew[box]  = false;
    simRxLost[box] = false;
    return result;
}

bool canStub_remote(const CanBox_t box)     { return canStub_isBoxValid(box); }
void canStub_restart(void)                  { }
uint32_t canStub_lastError(void)            { return 0U; }

void canSim_inject(const CanBox_t box, const uint8_t frame[CAN_MAX_DLC])
{
    if (!canStub_isBoxValid(box)) { return; }

    if (simRxNew[box]) { simRxLost[box] = true; }
    memcpy(simRx[box], frame, CAN_MAX_DLC);
    simRxNew[box] = true;
    can_handle_message(box);
}

bool canSim_takeTx(const CanBox_t box, uint8_t frame[CAN_MAX_DLC])
{
    if (!canStub_isBoxValid(box) || !simTxNew[box]) { return false; }

    memcpy(frame, simTx[box], CAN_MAX_DLC);
    simTxNew[box] = false;
    can_handle_message(box);                    /* the frame is "sent" now */
    return true;
}

void canSim_busOff(void)
{
    can_handle_error(0x80U, true);
}

#else
  #error "No CAN stub for this BOARD"
#endif
