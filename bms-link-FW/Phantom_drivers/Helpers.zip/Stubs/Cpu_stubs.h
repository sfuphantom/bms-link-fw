/*
 * Cpu_stubs.h
 *
 *  Interrupt masking and compiler bits that change with the board.
 */

#ifndef CPU_STUBS_H_
#define CPU_STUBS_H_

#include <stdint.h>
#include "Board_Select.h"

uint32_t cpu_enterCritical(void);                   /* returns the state to give back */
void     cpu_exitCritical(const uint32_t state);

/* Short critical section, "state" is a uint32_t the caller declares.
 * Define both before this header to use the RTOS ones (taskENTER_CRITICAL...). */
#ifndef CRITICAL_ENTER
  #define CRITICAL_ENTER(state)     ((state) = cpu_enterCritical())
  #define CRITICAL_EXIT(state)      cpu_exitCritical(state)
#endif

/* A function the application may replace with its own (TI also needs #pragma WEAK) */
#if defined(__GNUC__)
  #define WEAK_FN   __attribute__((weak))
#else
  #define WEAK_FN
#endif

#endif /* CPU_STUBS_H_ */
