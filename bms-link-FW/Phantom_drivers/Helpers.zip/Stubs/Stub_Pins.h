/*
 * Stub_Pins.h
 *
 *  Physical pins, ports and modules of the chip. Only the stubs and
 *  PhantomPinAlloc.c include this. Helpers must not: they only know the names.
 */

#ifndef STUB_PINS_H_
#define STUB_PINS_H_

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include "Board_Select.h"
#include "PhantomPinAlloc.h"

#if (BOARD == BOARD_TMS570_HW) || (BOARD == BOARD_SIL)

/*------------------------------------------------------------------------
 * GIO. Every port with gioPORT_t style registers.
 *----------------------------------------------------------------------*/
typedef enum {
    GIO_PORT_A,
    GIO_PORT_B,
    GIO_PORT_SPI1,
    GIO_PORT_SPI2,
    GIO_PORT_SPI3,
    GIO_PORT_SPI4,
    GIO_PORT_SPI5,
    GIO_PORT_HET1,
    GIO_PORT_HET2,
    GIO_PORT_COUNT
} GioPort_t;

/* pins on each port, same order as the enum */
#define GIO_PORT_PIN_COUNTS     { 8U, 8U, 12U, 12U, 12U, 12U, 12U, 32U, 32U }

/* only GIO A and B have interrupts */
#define GIO_PORT_HAS_IRQ(port)  (((port) == GIO_PORT_A) || ((port) == GIO_PORT_B))

typedef uint32_t GioPin_t;                              /* port * 32 + bit */
#define GIO_NO_PIN              0xFFFFFFFFU
#define GIO_PIN(port, bit)      (((uint32_t)(port) * 32U) + (uint32_t)(bit))
#define GIO_PIN_PORT(pin)       ((uint32_t)(pin) / 32U)
#define GIO_PIN_BIT(pin)        ((uint32_t)(pin) % 32U)

#define PIN_A(bit)              GIO_PIN(GIO_PORT_A, (bit))
#define PIN_B(bit)              GIO_PIN(GIO_PORT_B, (bit))
#define PIN_HET(n, bit)         GIO_PIN(GIO_PORT_HET1 + (n) - 1, (bit))     /* n = 1..2 */
/* SPI n = 1..5, bit: 0-7 CS0-CS7, 8 ENA, 9 CLK, 10 SIMO, 11 SOMI */
#define PIN_SPI(n, bit)         GIO_PIN(GIO_PORT_SPI1 + (n) - 1, (bit))

/*------------------------------------------------------------------------
 * PWM. HET modules make PWM (outputs), eCAP modules measure it (inputs).
 *----------------------------------------------------------------------*/
typedef enum {
    PWM_MOD_HET1,
    PWM_MOD_HET2,
    PWM_MOD_ECAP1,
    PWM_MOD_ECAP2,
    PWM_MOD_ECAP3,
    PWM_MOD_ECAP4,
    PWM_MOD_ECAP5,
    PWM_MOD_ECAP6,
    PWM_MOD_COUNT
} PwmModule_t;

#define PWM_MOD_IS_OUT(m)       ((m) <= PWM_MOD_HET2)
#define PWM_CHANNELS            8U          /* HET pwm0..pwm7, eCAP uses 0 */

typedef struct {
    PwmModule_t module;
    uint32_t    channel;
} PwmPin_t;

/*------------------------------------------------------------------------
 * CAN. Message box numbers are the HALCoGen ones, 0 is not a box.
 *----------------------------------------------------------------------*/
#define CAN_HW_NO_BOX           0U

/*------------------------------------------------------------------------
 * Allocation tables (PhantomPinAlloc.c)
 *----------------------------------------------------------------------*/
GioPin_t  alloc_gioPin(const GioName_t name);               /* GIO_NO_PIN if the name has no pin */
GioName_t alloc_gioName(const GioPin_t pin);                /* GIO_NONE if no name uses the pin */
bool      alloc_pwm(const PwmName_t name, PwmPin_t * const pin);
uint32_t  alloc_canHwBox(const CanBox_t box);               /* CAN_HW_NO_BOX if unknown */
CanBox_t  alloc_canBox(const uint32_t hwBox);               /* CAN_NO_BOX if unknown */

#else
  #error "No pin definitions for this BOARD"
#endif

#endif /* STUB_PINS_H_ */
