/*
 * PhantomPinAlloc.c
 *
 *  What goes where. Change a row to move a signal to another pin / module / box.
 *  Rows can be in any order.
 */

#include "PhantomPinAlloc.h"
#include "Stub_Pins.h"

#define ROWS(table)     (sizeof(table) / sizeof((table)[0]))

#if (BOARD == BOARD_TMS570_HW) || (BOARD == BOARD_SIL)

typedef struct { GioName_t name; GioPin_t pin; }    GioRow_t;
typedef struct { PwmName_t name; PwmPin_t pin; }    PwmRow_t;
typedef struct { CanBox_t  box;  uint32_t hwBox; }  CanRow_t;

static const GioRow_t gioRows[] = {
    { GIO_DEBUG_PIN,            PIN_A(2)        },
/*  { GIO_START_CHARGING_PIN,   PIN_A(5)        }, */
    { GIO_IMD_FAULT_PIN,        PIN_A(6)        },
    { GIO_BMS_FAULT_PIN,        PIN_A(7)        },
    { GIO_SLAVE_CS_PIN,         PIN_SPI(3, 0)   },
    { GIO_HV_CS_PIN,            PIN_SPI(3, 5)   }
};

static const PwmRow_t pwmRows[] = {
    { PWM_FAN_OUT,  { PWM_MOD_HET1,  0U } },        /* HET1 pwm0 */
    { PWM_IMD_IN,   { PWM_MOD_ECAP6, 0U } }
};

static const CanRow_t canRows[] = {
    { BMS2ALL_FAULT,        1U },
    { BMS2VCU_DATA,         3U },
    { VCU2BMS_DATA,         4U },
    { BMS2CHARGER_DATA,     6U },
    { CHARGER2BMS_DATA,     7U }
};

#else
  #error "No pin allocation for this BOARD"
#endif

GioPin_t alloc_gioPin(const GioName_t name)
{
    size_t i;

    for (i = 0U; i < ROWS(gioRows); i++) {
        if (gioRows[i].name == name) { return gioRows[i].pin; }
    }
    return GIO_NO_PIN;
}

GioName_t alloc_gioName(const GioPin_t pin)
{
    size_t i;

    for (i = 0U; i < ROWS(gioRows); i++) {
        if (gioRows[i].pin == pin) { return gioRows[i].name; }
    }
    return GIO_NONE;
}

bool alloc_pwm(const PwmName_t name, PwmPin_t * const pin)
{
    size_t i;

    for (i = 0U; i < ROWS(pwmRows); i++) {
        if (pwmRows[i].name == name) {
            *pin = pwmRows[i].pin;
            return true;
        }
    }
    return false;
}

uint32_t alloc_canHwBox(const CanBox_t box)
{
    size_t i;

    for (i = 0U; i < ROWS(canRows); i++) {
        if (canRows[i].box == box) { return canRows[i].hwBox; }
    }
    return CAN_HW_NO_BOX;
}

CanBox_t alloc_canBox(const uint32_t hwBox)
{
    size_t i;

    for (i = 0U; i < ROWS(canRows); i++) {
        if (canRows[i].hwBox == hwBox) { return canRows[i].box; }
    }
    return CAN_NO_BOX;
}
