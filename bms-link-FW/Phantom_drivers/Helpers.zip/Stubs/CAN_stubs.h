/*
 * CAN_stubs.h
 *
 *  One frame in or out of one message box (CanBox_t). Which hardware box
 *  and node that is, is decided by the stub and PhantomPinAlloc.c.
 */

#ifndef CAN_STUBS_H_
#define CAN_STUBS_H_

#include <stdint.h>
#include <stdbool.h>
#include "Board_Select.h"
#include "PhantomPinAlloc.h"

#define CAN_MAX_DLC     8U          /* bytes in one CAN frame */

typedef enum {
    CAN_RX_NONE,                    /* nothing new */
    CAN_RX_OK,
    CAN_RX_LOST                     /* data is valid, but a frame was lost before it */
} CanRx_t;

void     canStub_init(void);        /* canInit() + error interrupt on */
bool     canStub_isBoxValid(const CanBox_t box);
bool     canStub_tx(const CanBox_t box, const uint8_t frame[CAN_MAX_DLC]);     /* false = box busy */
CanRx_t  canStub_rx(const CanBox_t box, uint8_t frame[CAN_MAX_DLC]);
bool     canStub_remote(const CanBox_t box);
void     canStub_restart(void);     /* bus-off leaves the node stopped, this starts the recovery */
uint32_t canStub_lastError(void);   /* canERROR_*. Reading it clears the status flags */

/* Called from the interrupt, defined in Can_helpers.c.
 * RX box = a frame arrived, TX box = a frame was sent. level = canLEVEL_* of the error. */
void can_handle_message(const CanBox_t box);
void can_handle_error(const uint32_t level, const bool busOff);

#if BOARD == BOARD_SIL
/* Test side: put a frame in an RX box (fires the interrupt), take the last frame sent on a TX box
 * (that is when the TX box callback runs). */
void canSim_inject(const CanBox_t box, const uint8_t frame[CAN_MAX_DLC]);
bool canSim_takeTx(const CanBox_t box, uint8_t frame[CAN_MAX_DLC]);            /* false = nothing sent */
void canSim_busOff(void);
#endif

#endif /* CAN_STUBS_H_ */
