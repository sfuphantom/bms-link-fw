/*
 * SPI_stubs.c
 */

#include <stddef.h>
#include "SPI_stubs.h"

static volatile bool stopped = false;

#if BOARD == BOARD_TMS570_HW

#include "spi.h"
#include "reg_spi.h"
#include "PhantomTimers.h"

#ifndef REG_FOR_SPI
  #define REG_FOR_SPI           spiREG3
#endif

#define SPI_FMT_BYTE            SPI_FMT_0           /* 8 bit format in HALCoGen */
#define SPI_FMT_WORD            SPI_FMT_1           /* 16 bit format in HALCoGen */
#define SPI_HW_CSNR             0x01U               /* CS0 is a GIO pin here, so the hardware CS is not used */
#define SPI_ERR_FLAGS           0x5FU               /* DLENERR, TIMEOUT, PARITYERR, DESYNC, BITERR, RXOVR */
#define SPI_FLG_RXINT           0x100U
#define SPI_GCR1_SPIEN          (1UL << 24U)
#define SPI_BYTE_TIMEOUT_US     1000U               /* give up on one word after this */

/* 1 = use spiTransmitAndReceiveData from spi.h. That function has no timeout
 * and spiStub_setAbort cannot free it, so it stays 0 unless you accept that. */
#ifndef SPI_USE_HAL_EXCHANGE
  #define SPI_USE_HAL_EXCHANGE  0
#endif

uint32_t spiStub_errors(void)
{
    return REG_FOR_SPI->FLG & SPI_ERR_FLAGS;
}

void spiStub_clearErrors(void)
{
    REG_FOR_SPI->FLG = SPI_ERR_FLAGS;       /* write 1 to clear */
}

/* SPIEN low clears the shift registers, flags and buffers */
void spiStub_reset(void)
{
    REG_FOR_SPI->GCR1 &= ~SPI_GCR1_SPIEN;
    REG_FOR_SPI->GCR1 |=  SPI_GCR1_SPIEN;
}

#if SPI_USE_HAL_EXCHANGE

static SpiStatus_t exchangeWord(const SPIDATAFMT_t fmt, const uint16_t tx, uint16_t * const rx)
{
    spiDAT1_t config;
    uint16    txWord = tx;
    uint16    rxWord = 0U;

    config.CS_HOLD = 0U;
    config.WDEL    = 0U;
    config.DFSEL   = fmt;
    config.CSNR    = SPI_HW_CSNR;

    (void)spiTransmitAndReceiveData(REG_FOR_SPI, &config, 1U, &txWord, &rxWord);
    *rx = rxWord;
    return SPI_OK;
}

#else

static SpiStatus_t exchangeWord(const SPIDATAFMT_t fmt, const uint16_t tx, uint16_t * const rx)
{
    const ticks_t timeout = US_TO_TICKS(SPI_BYTE_TIMEOUT_US);
    ticks_t       start;

    REG_FOR_SPI->DAT1 = ((uint32_t)fmt << 24U) | ((uint32_t)SPI_HW_CSNR << 16U) | (uint32_t)tx;

    start = timer_tic_tick();
    while ((REG_FOR_SPI->FLG & SPI_FLG_RXINT) == 0U) {
        if (stopped)                           { return SPI_ERR_ABORTED; }
        if (hasTimeElapsed(start, timeout))    { return SPI_ERR_TIMEOUT; }
    }

    *rx = (uint16_t)REG_FOR_SPI->BUF;       /* reading BUF clears the RX flag */
    return SPI_OK;
}

#endif

SpiStatus_t spiStub_exchange(const SpiWidth_t width, const uint16_t tx, uint16_t * const rx)
{
    const SPIDATAFMT_t fmt = (width == SPI_WIDTH_16) ? SPI_FMT_WORD : SPI_FMT_BYTE;
    SpiStatus_t status;

    if (stopped) { return SPI_ERR_ABORTED; }

    status = exchangeWord(fmt, tx, rx);
    if (status != SPI_OK) { return status; }

    return (spiStub_errors() != 0U) ? SPI_ERR_BUS : SPI_OK;
}

#elif BOARD == BOARD_SIL

static SpiSimDevice_t simDevice = NULL;
static uint32_t       simErrors = 0U;

uint32_t spiStub_errors(void)       { return simErrors; }
void     spiStub_clearErrors(void)  { simErrors = 0U; }
void     spiStub_reset(void)        { }

SpiStatus_t spiStub_exchange(const SpiWidth_t width, const uint16_t tx, uint16_t * const rx)
{
    const uint16_t mask = (width == SPI_WIDTH_16) ? 0xFFFFU : 0x00FFU;

    if (stopped) { return SPI_ERR_ABORTED; }

    *rx = (uint16_t)(((simDevice != NULL) ? simDevice(tx) : tx) & mask);
    return (simErrors != 0U) ? SPI_ERR_BUS : SPI_OK;
}

void spiSim_setDevice(const SpiSimDevice_t device)  { simDevice = device; }
void spiSim_setErrors(const uint32_t flags)         { simErrors = flags; }

#else
  #error "No SPI stub for this BOARD"
#endif

void spiStub_setAbort(const bool on)    { stopped = on; }
bool spiStub_isAborted(void)            { return stopped; }
