/*
 * Board_Select.h
 *
 *  The one place that picks the board. Every stub is built for this board.
 *  Override from the compiler command line: -DBOARD=BOARD_SIL
 */

#ifndef BOARD_SELECT_H_
#define BOARD_SELECT_H_

#define BOARD_TMS570_HW     1       /* real chip, HALCoGen drivers */
#define BOARD_SIL           2       /* host build, simulated peripherals */
/* new board: add a number here, then a branch in each stub .c and in Stub_Pins.h */

#ifndef BOARD
  #define BOARD             BOARD_TMS570_HW
#endif

#if (BOARD != BOARD_TMS570_HW) && (BOARD != BOARD_SIL)
  #error "Unknown BOARD, see Board_Select.h"
#endif

#endif /* BOARD_SELECT_H_ */
