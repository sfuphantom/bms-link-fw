/*
 * SPI_stubs.h
 *
 *  One SPI word on the wire, error flags, reset and abort. No chip select,
 *  no locking, no multi byte logic: that is in spi_helpers.
 */

#ifndef SPI_STUBS_H_
#define SPI_STUBS_H_

#include <stdint.h>
#include <stdbool.h>
#include "Board_Select.h"

typedef enum {
    SPI_OK = 0,
    SPI_ERR_TIMEOUT,        /* no answer in time */
    SPI_ERR_BUS,            /* an error flag is set */
    SPI_ERR_ABORTED,        /* spiStub_setAbort(true) was called */
    SPI_ERR_BUSY,           /* someone else has the bus */
    SPI_ERR_ARG
} SpiStatus_t;

typedef enum { SPI_WIDTH_8, SPI_WIDTH_16 } SpiWidth_t;

SpiStatus_t spiStub_exchange(const SpiWidth_t width, const uint16_t tx, uint16_t * const rx);   /* one word */
uint32_t    spiStub_errors(void);           /* error flags that are set, 0 = none */
void        spiStub_clearErrors(void);
void        spiStub_reset(void);            /* drops whatever is being shifted */

/* While set, every exchange returns SPI_ERR_ABORTED. Safe to call from an interrupt. */
void        spiStub_setAbort(const bool on);
bool        spiStub_isAborted(void);

#if BOARD == BOARD_SIL
/* What the "device" answers. Without one, the word comes back as it was sent. */
typedef uint16_t (*SpiSimDevice_t)(const uint16_t tx);
void spiSim_setDevice(const SpiSimDevice_t device);
void spiSim_setErrors(const uint32_t flags);
#endif

#endif /* SPI_STUBS_H_ */
