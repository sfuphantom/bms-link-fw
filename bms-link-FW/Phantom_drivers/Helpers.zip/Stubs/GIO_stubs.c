/*
 * GIO_stubs.c
 */

#include "GIO_stubs.h"
#include "Stub_Pins.h"

#define MASK_OF(n)      ((uint32_t)1U << (n))

/*------------------------------------------------------------------------
 * Board layer: one port, one bit
 *----------------------------------------------------------------------*/
#if BOARD == BOARD_TMS570_HW

#include "gio.h"
#include "reg_gio.h"
#include "reg_spi.h"        /* spiPORTn */
#include "reg_het.h"        /* hetPORTn */

/* Every port here is a gioPORT_t. A port that is not listed gives NULL. */
static gioPORT_t *portReg(const GioPort_t port)
{
    switch (port) {
        case GIO_PORT_A:    return gioPORTA;
        case GIO_PORT_B:    return gioPORTB;
        case GIO_PORT_SPI1: return spiPORT1;
        case GIO_PORT_SPI2: return spiPORT2;
        case GIO_PORT_SPI3: return spiPORT3;
        case GIO_PORT_SPI4: return spiPORT4;
        case GIO_PORT_SPI5: return spiPORT5;
        case GIO_PORT_HET1: return hetPORT1;
        case GIO_PORT_HET2: return hetPORT2;
        default:            return NULL;
    }
}

static GioLevel_t portRead(const GioPort_t port, const uint32_t bit)
{
    return (gioGetBit(portReg(port), bit) != 0U) ? GIO_HIGH : GIO_LOW;
}

static void portWrite(const GioPort_t port, const uint32_t bit, const GioLevel_t level)
{
    gioSetBit(portReg(port), bit, (uint32)level);
}

static void portToggle(const GioPort_t port, const uint32_t bit)
{
    gioToggleBit(portReg(port), bit);
}

static void portSetDir(const GioPort_t port, const uint32_t bit, const GioDir_t dir)
{
    gioPORT_t * const reg  = portReg(port);
    const uint32_t    mask = MASK_OF(bit);

    gioSetDirection(reg, (dir == GIO_OUTPUT) ? (reg->DIR | mask) : (reg->DIR & ~mask));
}

static void portWriteMask(const GioPort_t port, const uint32_t mask, const GioLevel_t level)
{
    gioPORT_t * const reg = portReg(port);

    if (level == GIO_HIGH) { reg->DSET = mask; }
    else                   { reg->DCLR = mask; }
}

static void portIrq(const GioPort_t port, const uint32_t bit, const bool enable)
{
    if (enable) { gioEnableNotification(portReg(port), bit); }
    else        { gioDisableNotification(portReg(port), bit); }
}

#elif BOARD == BOARD_SIL

static uint32_t simLevel[GIO_PORT_COUNT];
static uint32_t simIrq[GIO_PORT_COUNT];

static GioLevel_t portRead(const GioPort_t port, const uint32_t bit)
{
    return (((simLevel[port] >> bit) & 1U) != 0U) ? GIO_HIGH : GIO_LOW;
}

static void portWriteMask(const GioPort_t port, const uint32_t mask, const GioLevel_t level)
{
    if (level == GIO_HIGH) { simLevel[port] |= mask; }
    else                   { simLevel[port] &= ~mask; }
}

static void portWrite(const GioPort_t port, const uint32_t bit, const GioLevel_t level)
{
    portWriteMask(port, MASK_OF(bit), level);
}

static void portToggle(const GioPort_t port, const uint32_t bit)
{
    simLevel[port] ^= MASK_OF(bit);
}

static void portSetDir(const GioPort_t port, const uint32_t bit, const GioDir_t dir)
{
    (void)port; (void)bit; (void)dir;       /* the sim has no pad, outputs and inputs share one level */
}

static void portIrq(const GioPort_t port, const uint32_t bit, const bool enable)
{
    if (enable) { simIrq[port] |= MASK_OF(bit); }
    else        { simIrq[port] &= ~MASK_OF(bit); }
}

#else
  #error "No GIO stub for this BOARD"
#endif

/*------------------------------------------------------------------------
 * Name -> port and bit. false if the name has no pin.
 *----------------------------------------------------------------------*/
static const uint8_t portPins[GIO_PORT_COUNT] = GIO_PORT_PIN_COUNTS;

static bool decode(const GioName_t name, GioPort_t * const port, uint32_t * const bit)
{
    const GioPin_t pin = alloc_gioPin(name);
    const uint32_t id  = GIO_PIN_PORT(pin);

    if (id >= (uint32_t)GIO_PORT_COUNT)         { return false; }   /* also GIO_NO_PIN */
    if (GIO_PIN_BIT(pin) >= portPins[id])       { return false; }

    *port = (GioPort_t)id;
    *bit  = GIO_PIN_BIT(pin);
    return true;
}

GioLevel_t gioStub_read(const GioName_t name)
{
    GioPort_t port;
    uint32_t  bit;

    if (!decode(name, &port, &bit)) { return GIO_LOW; }
    return portRead(port, bit);
}

void gioStub_write(const GioName_t name, const GioLevel_t level)
{
    GioPort_t port;
    uint32_t  bit;

    if (decode(name, &port, &bit)) { portWrite(port, bit, level); }
}

void gioStub_toggle(const GioName_t name)
{
    GioPort_t port;
    uint32_t  bit;

    if (decode(name, &port, &bit)) { portToggle(port, bit); }
}

void gioStub_setDirection(const GioName_t name, const GioDir_t dir)
{
    GioPort_t port;
    uint32_t  bit;

    if (decode(name, &port, &bit)) { portSetDir(port, bit, dir); }
}

void gioStub_writeMany(const GioName_t * const pins, const size_t count, const GioLevel_t level)
{
    uint32_t  masks[GIO_PORT_COUNT] = { 0U };
    GioPort_t port;
    uint32_t  bit;
    uint32_t  p;
    size_t    i;

    for (i = 0U; i < count; i++) {
        if (decode(pins[i], &port, &bit)) { masks[port] |= MASK_OF(bit); }
    }
    for (p = 0U; p < (uint32_t)GIO_PORT_COUNT; p++) {
        if (masks[p] != 0U) { portWriteMask((GioPort_t)p, masks[p], level); }
    }
}

bool gioStub_irqEnable(const GioName_t name)
{
    GioPort_t port;
    uint32_t  bit;

    if (!decode(name, &port, &bit) || !GIO_PORT_HAS_IRQ(port)) { return false; }

    portIrq(port, bit, true);
    return true;
}

void gioStub_irqDisable(const GioName_t name)
{
    GioPort_t port;
    uint32_t  bit;

    if (decode(name, &port, &bit) && GIO_PORT_HAS_IRQ(port)) { portIrq(port, bit, false); }
}

/*------------------------------------------------------------------------
 * Interrupts
 *----------------------------------------------------------------------*/
static void irqFired(const GioPort_t port, const uint32_t bit)
{
    const GioName_t name = alloc_gioName(GIO_PIN(port, bit));

    if (name != GIO_NONE) { gio_handleInterrupt(name); }
}

#if BOARD == BOARD_TMS570_HW

/* HALCoGen callback: only forwards */
void gioNotification(gioPORT_t *port, uint32 bit)
{
    if (port == gioPORTA)      { irqFired(GIO_PORT_A, bit); }
    else if (port == gioPORTB) { irqFired(GIO_PORT_B, bit); }
}

#elif BOARD == BOARD_SIL

void gioSim_set(const GioName_t name, const GioLevel_t level)
{
    GioPort_t port;
    uint32_t  bit;
    bool      changed;

    if (!decode(name, &port, &bit)) { return; }

    changed = (portRead(port, bit) != level);
    portWrite(port, bit, level);

    if (changed && GIO_PORT_HAS_IRQ(port) && (((simIrq[port] >> bit) & 1U) != 0U)) {
        irqFired(port, bit);
    }
}

#endif
