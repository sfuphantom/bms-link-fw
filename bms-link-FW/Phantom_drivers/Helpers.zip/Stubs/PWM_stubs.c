/*
 * PWM_stubs.c
 */

#include "PWM_stubs.h"
#include "Stub_Pins.h"

/*------------------------------------------------------------------------
 * Board layer
 *----------------------------------------------------------------------*/
#if BOARD == BOARD_TMS570_HW

#include "het.h"
#include "ecap.h"
#include "reg_het.h"
#include "reg_ecap.h"

/* The eCAP counter clock. Set it to the clock of your eCAP in HALCoGen. */
#ifndef PWM_CAP_CLOCK_HZ
  #define PWM_CAP_CLOCK_HZ      75000000UL
#endif

static hetRAMBASE_t *hetRam(const PwmModule_t module)
{
    return (module == PWM_MOD_HET1) ? hetRAM1 : hetRAM2;
}

static ecapBASE_t *ecapReg(const PwmModule_t module)
{
    switch (module) {
        case PWM_MOD_ECAP1: return ecapREG1;
        case PWM_MOD_ECAP2: return ecapREG2;
        case PWM_MOD_ECAP3: return ecapREG3;
        case PWM_MOD_ECAP4: return ecapREG4;
        case PWM_MOD_ECAP5: return ecapREG5;
        case PWM_MOD_ECAP6: return ecapREG6;
        default:            return NULL;
    }
}

static void outWrite(const PwmPin_t pin, const PwmSignal_t * const sig)
{
    hetSIGNAL_t s;

    s.duty   = (uint32)(sig->dutyPct + 0.5f);
    s.period = (float64)sig->periodUs;
    pwmSetSignal(hetRam(pin.module), pin.channel, s);
}

static void outSetDuty(const PwmPin_t pin, const float dutyPct)
{
    pwmSetDuty(hetRam(pin.module), pin.channel, (uint32)(dutyPct + 0.5f));
}

static void outRun(const PwmPin_t pin, const bool on)
{
    if (on) { pwmStart(hetRam(pin.module), pin.channel); }
    else    { pwmStop(hetRam(pin.module), pin.channel); }
}

static bool outRead(const PwmPin_t pin, PwmSignal_t * const sig)
{
    hetSIGNAL_t s;

    pwmGetSignal(hetRam(pin.module), pin.channel, &s);
    sig->dutyPct  = (float)s.duty;
    sig->periodUs = (float)s.period;
    return sig->periodUs > 0.0f;
}

/* eCAP set up as: rising (1), falling (2), rising with counter reset (3).
 * period = CAP3 - CAP1, high time = CAP2 - CAP1 */
static bool inRead(const PwmPin_t pin, PwmSignal_t * const sig)
{
    ecapBASE_t * const ecap   = ecapReg(pin.module);
    const uint32_t     t1     = ecapGetCAP1(ecap);
    const uint32_t     high   = ecapGetCAP2(ecap) - t1;
    const uint32_t     period = ecapGetCAP3(ecap) - t1;

    if (period == 0U || high > period) { return false; }

    sig->dutyPct  = 100.0f * (float)high / (float)period;
    sig->periodUs = 1000000.0f * (float)period / (float)PWM_CAP_CLOCK_HZ;
    return true;
}

#elif BOARD == BOARD_SIL

static PwmSignal_t simSig[PWM_MOD_COUNT][PWM_CHANNELS];
static bool        simRun[PWM_MOD_COUNT][PWM_CHANNELS];

static void outWrite(const PwmPin_t pin, const PwmSignal_t * const sig)
{
    simSig[pin.module][pin.channel] = *sig;
}

static void outSetDuty(const PwmPin_t pin, const float dutyPct)
{
    simSig[pin.module][pin.channel].dutyPct = dutyPct;
}

static void outRun(const PwmPin_t pin, const bool on)
{
    simRun[pin.module][pin.channel] = on;
}

static bool outRead(const PwmPin_t pin, PwmSignal_t * const sig)
{
    *sig = simSig[pin.module][pin.channel];
    return sig->periodUs > 0.0f;
}

static bool inRead(const PwmPin_t pin, PwmSignal_t * const sig)
{
    return outRead(pin, sig);
}

#else
  #error "No PWM stub for this BOARD"
#endif

/*------------------------------------------------------------------------
 * Name -> module and channel, and a wrong kind check
 *----------------------------------------------------------------------*/
static bool lookup(const PwmName_t name, const bool wantOutput, PwmPin_t * const pin)
{
    if (!alloc_pwm(name, pin))                      { return false; }
    if (pin->channel >= PWM_CHANNELS)               { return false; }
    return PWM_MOD_IS_OUT(pin->module) == wantOutput;
}

static float clampPct(const float pct)
{
    if (!(pct > 0.0f)) { return 0.0f; }             /* also catches NaN */
    return (pct > 100.0f) ? 100.0f : pct;
}

bool pwmStub_write(const PwmName_t name, const PwmSignal_t * const sig)
{
    PwmPin_t    pin;
    PwmSignal_t clean;

    if (!lookup(name, true, &pin) || sig->periodUs <= 0.0f) { return false; }

    clean.dutyPct  = clampPct(sig->dutyPct);
    clean.periodUs = sig->periodUs;
    outWrite(pin, &clean);
    return true;
}

bool pwmStub_setDuty(const PwmName_t name, const float dutyPct)
{
    PwmPin_t pin;

    if (!lookup(name, true, &pin)) { return false; }

    outSetDuty(pin, clampPct(dutyPct));
    return true;
}

bool pwmStub_start(const PwmName_t name)
{
    PwmPin_t pin;

    if (!lookup(name, true, &pin)) { return false; }

    outRun(pin, true);
    return true;
}

bool pwmStub_stop(const PwmName_t name)
{
    PwmPin_t pin;

    if (!lookup(name, true, &pin)) { return false; }

    outRun(pin, false);
    return true;
}

bool pwmStub_read(const PwmName_t name, PwmSignal_t * const sig)
{
    PwmPin_t pin;

    if (!alloc_pwm(name, &pin) || pin.channel >= PWM_CHANNELS) { return false; }

    return PWM_MOD_IS_OUT(pin.module) ? outRead(pin, sig) : inRead(pin, sig);
}

#if BOARD == BOARD_SIL

void pwmSim_set(const PwmName_t name, const PwmSignal_t * const sig)
{
    PwmPin_t pin;

    if (alloc_pwm(name, &pin) && pin.channel < PWM_CHANNELS) { simSig[pin.module][pin.channel] = *sig; }
}

#endif
