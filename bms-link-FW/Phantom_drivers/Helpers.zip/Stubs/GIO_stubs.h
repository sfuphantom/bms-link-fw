/*
 * GIO_stubs.h
 *
 *  Pin access by name (GioName_t). The only place that knows which port and
 *  bit a name is on is the stub; the helpers never see ports or pins.
 *  Unknown or unallocated names are ignored, reads give GIO_LOW.
 */

#ifndef GIO_STUBS_H_
#define GIO_STUBS_H_

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include "Board_Select.h"
#include "PhantomPinAlloc.h"

typedef enum { GIO_LOW = 0, GIO_HIGH = 1 } GioLevel_t;
typedef enum { GIO_INPUT = 0, GIO_OUTPUT = 1 } GioDir_t;

GioLevel_t gioStub_read(const GioName_t pin);
void       gioStub_write(const GioName_t pin, const GioLevel_t level);
void       gioStub_toggle(const GioName_t pin);
void       gioStub_setDirection(const GioName_t pin, const GioDir_t dir);

/* Pins on the same port change in one write */
void       gioStub_writeMany(const GioName_t * const pins, const size_t count, const GioLevel_t level);

/* Interrupts (GIO A and B only). Edge and priority are still set in HALCoGen.
 * false = the pin has no interrupt. */
bool       gioStub_irqEnable(const GioName_t pin);
void       gioStub_irqDisable(const GioName_t pin);

/* Called from the interrupt, defined in GIO_helpers.c */
void       gio_handleInterrupt(const GioName_t pin);

#if BOARD == BOARD_SIL
/* Drive a pin from a test. Fires the interrupt if it is enabled and the level changed. */
void       gioSim_set(const GioName_t pin, const GioLevel_t level);
#endif

#endif /* GIO_STUBS_H_ */
