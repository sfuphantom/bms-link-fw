/*
 * Cpu_stubs.c
 */

#include "Cpu_stubs.h"

#if (BOARD == BOARD_TMS570_HW) && defined(__TI_COMPILER_VERSION__)

#include "sys_common.h"

uint32_t cpu_enterCritical(void)
{
    const uint32_t cpsr = _get_CPSR();

    _disable_IRQ();
    return cpsr;
}

void cpu_exitCritical(const uint32_t state)
{
    if ((state & 0x80U) == 0U) { _enable_IRQ(); }   /* IRQs were on before */
}

#elif (BOARD == BOARD_TMS570_HW) || (BOARD == BOARD_SIL)

/* nothing can interrupt a single threaded host build */
uint32_t cpu_enterCritical(void)                    { return 0U; }
void     cpu_exitCritical(const uint32_t state)     { (void)state; }

#else
  #error "No CPU stub for this BOARD"
#endif
