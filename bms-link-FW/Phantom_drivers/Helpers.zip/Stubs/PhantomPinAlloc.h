/*
 * PhantomPinAlloc.h
 *
 *  The names the application uses. Which pin / module / box each name is
 *  on is decided in PhantomPinAlloc.c, per board. Helpers only see these names.
 */

#ifndef PHANTOM_PIN_ALLOC_H_
#define PHANTOM_PIN_ALLOC_H_

/* GPIO pins */
typedef enum {
    GIO_DEBUG_PIN,
/*  GIO_START_CHARGING_PIN, */
    GIO_IMD_FAULT_PIN,
    GIO_BMS_FAULT_PIN,
    GIO_SLAVE_CS_PIN,
    GIO_HV_CS_PIN,
    GIO_NAME_COUNT
} GioName_t;

#define GIO_NONE    ((GioName_t)GIO_NAME_COUNT)     /* "no pin", for example no clock pin */

/* PWM signals, outputs and inputs */
typedef enum {
    PWM_FAN_OUT,
    PWM_IMD_IN,
    PWM_NAME_COUNT
} PwmName_t;

/* CAN message boxes. The order is the order of the table in Can_helpers.c */
typedef enum {
    BMS2ALL_FAULT,
    BMS2VCU_DATA,
    VCU2BMS_DATA,
    BMS2CHARGER_DATA,
    CHARGER2BMS_DATA,
    CAN_BOX_COUNT
} CanBox_t;

#define CAN_NO_BOX  ((CanBox_t)CAN_BOX_COUNT)

#endif /* PHANTOM_PIN_ALLOC_H_ */
