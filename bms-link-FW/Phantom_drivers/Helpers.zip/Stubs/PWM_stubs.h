/*
 * PWM_stubs.h
 *
 *  Write PWM outputs and read PWM signals (outputs or inputs) by name.
 */

#ifndef PWM_STUBS_H_
#define PWM_STUBS_H_

#include <stdint.h>
#include <stdbool.h>
#include "Board_Select.h"
#include "PhantomPinAlloc.h"

typedef struct {
    float dutyPct;      /* 0 to 100 */
    float periodUs;
} PwmSignal_t;

/* All return false if the name is not allocated or is the wrong kind (input / output).
 * The duty is cut to 0..100. The HET hardware only does whole percents. */
bool pwmStub_write(const PwmName_t pwm, const PwmSignal_t * const sig);     /* outputs */
bool pwmStub_setDuty(const PwmName_t pwm, const float dutyPct);             /* outputs, same period */
bool pwmStub_start(const PwmName_t pwm);                                    /* outputs */
bool pwmStub_stop(const PwmName_t pwm);                                     /* outputs */
bool pwmStub_read(const PwmName_t pwm, PwmSignal_t * const sig);            /* output: what is set, input: measured. false = no signal */

#if BOARD == BOARD_SIL
void pwmSim_set(const PwmName_t pwm, const PwmSignal_t * const sig);        /* drive an input from a test */
#endif

#endif /* PWM_STUBS_H_ */
