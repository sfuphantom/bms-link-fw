/*
 * UART_stubs.c
 */

#include "UART_stubs.h"

#if BOARD == BOARD_TMS570_HW

#include "sci.h"
#include "reg_sci.h"

#define USE_USB_N_PINS 1
#if USE_USB_N_PINS
    #define UART_REG        sciREG
#else
    #define UART_REG        scilinREG
#endif

/* sciSend has to be in polling mode (no TX interrupt), the data is on the stack. */
void uartStub_write(const uint8_t * const data, const uint16_t len)
{
    sciSend(UART_REG, len, (uint8_t *)data);        /* sciSend does not change the data, it just has no const */
}

bool uartStub_readByte(uint8_t * const byte)
{
    if (!sciIsRxReady(UART_REG)) { return false; }

    *byte = (uint8_t)sciReceiveByte(UART_REG);
    return true;
}

#elif BOARD == BOARD_SIL

#include <stdio.h>

#define SIM_RX_SIZE     256U                        /* power of 2 */

static uint8_t  rxBuf[SIM_RX_SIZE];
static uint32_t rxHead = 0U;
static uint32_t rxTail = 0U;

/* the frames go to stdout, pipe them into uart_receiver */
void uartStub_write(const uint8_t * const data, const uint16_t len)
{
    (void)fwrite(data, 1U, len, stdout);
}

bool uartStub_readByte(uint8_t * const byte)
{
    if (rxTail == rxHead) { return false; }

    *byte = rxBuf[rxTail % SIM_RX_SIZE];
    rxTail++;
    return true;
}

void uartSim_push(const uint8_t byte)
{
    if ((rxHead - rxTail) >= SIM_RX_SIZE) { return; }   /* full, drop it */

    rxBuf[rxHead % SIM_RX_SIZE] = byte;
    rxHead++;
}

#else
  #error "No UART stub for this BOARD"
#endif
