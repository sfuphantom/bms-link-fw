/*
 * UART_stubs.h
 *
 *  Raw bytes in and out of the log UART.
 */

#ifndef UART_STUBS_H_
#define UART_STUBS_H_

#include <stdint.h>
#include <stdbool.h>
#include "Board_Select.h"

void uartStub_write(const uint8_t * const data, const uint16_t len);   /* sends everything before it returns */
bool uartStub_readByte(uint8_t * const byte);                          /* false if nothing received, never waits */

#if BOARD == BOARD_SIL
void uartSim_push(const uint8_t byte);      /* a byte "received" from the pc */
#endif

#endif /* UART_STUBS_H_ */
